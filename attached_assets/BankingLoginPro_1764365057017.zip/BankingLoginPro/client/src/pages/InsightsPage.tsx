import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { mockUser } from "@/lib/mockData";
import { TrendingUp, AlertTriangle, CheckCircle2, DollarSign } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Legend } from 'recharts';
import { useFinance } from "@/context/FinancialContext"; // UPDATED
import { translations } from "@/lib/translations"; // UPDATED

const savingsTrend = [
  { month: 'Jun', savings: 4000 },
  { month: 'Jul', savings: 3500 },
  { month: 'Aug', savings: 5200 },
  { month: 'Sep', savings: 4800 },
  { month: 'Oct', savings: 6000 },
  { month: 'Nov', savings: 6800 },
];

const overspendingData = [
  { category: 'Food', amount: 1200, limit: 1000 },
  { category: 'Transport', amount: 800, limit: 1200 },
  { category: 'Coffee', amount: 450, limit: 200 },
];

export default function InsightsPage() {
  const { language } = useFinance();
  const t = translations[language];

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold font-heading">{t.insights}</h1>
        <div className="text-sm text-muted-foreground">Last updated: Today</div>
      </div>

      {/* Top Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-gradient-to-br from-emerald-900/40 to-emerald-800/10 border-emerald-500/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-emerald-400">Net Worth Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-100">+12.5%</div>
            <p className="text-xs text-emerald-400/70 mt-1">Growth over last 6 months</p>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-amber-900/40 to-amber-800/10 border-amber-500/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-amber-400">Leakage Alert</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-amber-100">₹2,450</div>
            <p className="text-xs text-amber-400/70 mt-1">Overspent on Food & Coffee</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-900/40 to-blue-800/10 border-blue-500/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-blue-400">Projected Savings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-100">₹82,000</div>
            <p className="text-xs text-blue-400/70 mt-1">By March 2026 if you stick to plan</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Savings Chart */}
        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle>Savings Growth</CardTitle>
            <CardDescription>Your savings trajectory over the last 6 months</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={savingsTrend}>
                <defs>
                  <linearGradient id="colorSavings" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `₹${value}`} />
                <Tooltip 
                  contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))' }}
                  itemStyle={{ color: 'hsl(var(--primary))' }}
                />
                <Area type="monotone" dataKey="savings" stroke="hsl(var(--primary))" fillOpacity={1} fill="url(#colorSavings)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Overspending Chart */}
        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle>Spending vs Limits</CardTitle>
            <CardDescription>Categories where you exceeded your budget</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={overspendingData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" horizontal={true} vertical={false} />
                <XAxis type="number" hide />
                <YAxis dataKey="category" type="category" width={80} stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip cursor={{fill: 'transparent'}} contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))' }} />
                <Legend />
                <Bar dataKey="limit" name="Budget Limit" fill="hsl(var(--muted))" radius={[0, 4, 4, 0]} barSize={20} />
                <Bar dataKey="amount" name="Actual Spent" fill="hsl(var(--destructive))" radius={[0, 4, 4, 0]} barSize={20} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Credit Score Card */}
      <Card className="border-border bg-card overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-red-500 via-yellow-500 to-green-500"></div>
        <CardHeader>
           <CardTitle className="flex items-center gap-2">
             <DollarSign className="text-primary" /> Estimated Credit Score
           </CardTitle>
        </CardHeader>
        <CardContent className="grid md:grid-cols-2 gap-8 items-center">
          <div className="text-center md:text-left">
            <div className="text-5xl font-bold text-foreground">680–720</div>
            <div className="text-sm text-muted-foreground mt-2">Based on mock data analysis</div>
            <div className="mt-4 flex gap-2 justify-center md:justify-start">
              <span className="h-2 w-12 rounded-full bg-red-500/30"></span>
              <span className="h-2 w-12 rounded-full bg-yellow-500/30"></span>
              <span className="h-2 w-12 rounded-full bg-green-500"></span>
              <span className="h-2 w-12 rounded-full bg-emerald-500/30"></span>
            </div>
          </div>
          
          <div className="bg-secondary/30 p-6 rounded-xl border border-border">
            <h4 className="font-bold mb-3 flex items-center gap-2">
              <TrendingUp size={16} /> {t.tips}
            </h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2">
                <CheckCircle2 size={16} className="text-emerald-500 mt-0.5 shrink-0" />
                <span>Pay your EMI of ₹3,500 on time next week.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 size={16} className="text-emerald-500 mt-0.5 shrink-0" />
                <span>Keep UPI spending below 30% of total income.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 size={16} className="text-emerald-500 mt-0.5 shrink-0" />
                <span>Maintain at least 20% surplus each month in savings.</span>
              </li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
