import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Target, Trophy, Coffee, Bike, ShieldAlert, Trash2, Users } from "lucide-react";
import { useFinance } from "@/context/FinancialContext"; // UPDATED
import { translations } from "@/lib/translations"; // UPDATED
import { useToast } from "@/hooks/use-toast";
import { Goal, Challenge } from "@/lib/mockData";

export default function GoalsPage() {
  const { 
    goals, addGoal, deleteGoal, 
    challenges, joinChallenge, 
    language 
  } = useFinance();
  const t = translations[language];
  const { toast } = useToast();

  // Form states
  const [newGoal, setNewGoal] = useState({ title: "", amount: "", date: "", priority: "Medium" });
  const [isGoalDialogOpen, setIsGoalDialogOpen] = useState(false);
  
  const [newChallenge, setNewChallenge] = useState({ title: "", limit: "", unit: "week" });
  const [isChallengeDialogOpen, setIsChallengeDialogOpen] = useState(false);
  const [isViewPlanOpen, setIsViewPlanOpen] = useState(false);
  const [selectedGoal, setSelectedGoal] = useState<Goal | null>(null);

  const handleAddGoal = () => {
    if (!newGoal.title || !newGoal.amount) return;
    
    addGoal({
      title: newGoal.title,
      targetAmount: parseInt(newGoal.amount),
      deadline: newGoal.date || "Flexible",
      priority: newGoal.priority as any,
    });

    setIsGoalDialogOpen(false);
    setNewGoal({ title: "", amount: "", date: "", priority: "Medium" });
    
    toast({
      title: t.success,
      description: "Goal added successfully.",
    });
  };

  const handleAddChallenge = () => {
    if (!newChallenge.title || !newChallenge.limit) return;

    joinChallenge({
        title: newChallenge.title,
        limit: parseInt(newChallenge.limit),
        unit: newChallenge.unit,
    });

    setIsChallengeDialogOpen(false);
    setNewChallenge({ title: "", limit: "", unit: "week" });
    
    toast({
      title: t.success,
      description: "Challenge joined.",
    });
  };

  const handleViewPlan = (goal: Goal) => {
    setSelectedGoal(goal);
    setIsViewPlanOpen(true);
  };

  const getGoalIcon = (title: string) => {
    const t = title.toLowerCase();
    if (t.includes("bike") || t.includes("car")) return <Bike className="text-primary" />;
    if (t.includes("emergency")) return <ShieldAlert className="text-red-400" />;
    return <Target className="text-accent" />;
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-secondary to-card border border-border p-6 rounded-2xl flex flex-col md:flex-row items-start md:items-center gap-4 shadow-lg">
        <div className="p-3 bg-primary/10 rounded-xl text-primary">
          <Trophy size={28} />
        </div>
        <div>
          <h2 className="text-lg font-bold font-heading">{t.goals}</h2>
          <p className="text-sm text-muted-foreground max-w-xl">
            Track your dreams and build better habits.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* GOALS SECTION */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold font-heading flex items-center gap-2">
              <Target className="text-primary" /> {t.activeGoals}
            </h2>
            
            <Dialog open={isGoalDialogOpen} onOpenChange={setIsGoalDialogOpen}>
              <DialogTrigger asChild>
                <Button className="font-bold">
                  <Plus className="mr-2 h-4 w-4" /> {t.addGoal}
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-card border-border text-foreground sm:max-w-[425px]">
                <DialogHeader>
                  <DialogTitle>{t.addGoal}</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="goal-name">{t.title}</Label>
                    <Input 
                      id="goal-name" 
                      placeholder="e.g. New Laptop" 
                      value={newGoal.title}
                      onChange={(e) => setNewGoal({...newGoal, title: e.target.value})}
                      className="bg-secondary/50"
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="amount">{t.amount} (₹)</Label>
                    <Input 
                      id="amount" 
                      type="number" 
                      placeholder="50000" 
                      value={newGoal.amount}
                      onChange={(e) => setNewGoal({...newGoal, amount: e.target.value})}
                      className="bg-secondary/50"
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="date">{t.deadline}</Label>
                    <Input 
                      id="date" 
                      type="date" 
                      value={newGoal.date}
                      onChange={(e) => setNewGoal({...newGoal, date: e.target.value})}
                      className="bg-secondary/50"
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="priority">{t.priority}</Label>
                    <Select 
                      value={newGoal.priority} 
                      onValueChange={(val) => setNewGoal({...newGoal, priority: val})}
                    >
                      <SelectTrigger className="bg-secondary/50">
                        <SelectValue placeholder="Select priority" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="High">High</SelectItem>
                        <SelectItem value="Medium">Medium</SelectItem>
                        <SelectItem value="Low">Low</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <DialogFooter>
                  <Button onClick={handleAddGoal} className="font-bold">{t.save}</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          <div className="space-y-4">
            {goals.map((goal) => (
              <Card key={goal.id} className="border-border bg-card hover:border-primary/50 transition-colors group relative">
                <CardContent className="p-6">
                   <Button 
                     variant="ghost" 
                     size="icon" 
                     className="absolute top-4 right-4 text-muted-foreground hover:text-red-500 h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
                     onClick={() => deleteGoal(goal.id)}
                   >
                     <Trash2 size={16} />
                   </Button>

                  <div className="flex justify-between items-start mb-4 pr-8">
                    <div className="flex items-center gap-3">
                      <div className="bg-secondary p-2.5 rounded-lg group-hover:bg-primary/10 transition-colors">
                        {getGoalIcon(goal.title)}
                      </div>
                      <div>
                        <h3 className="font-bold text-lg">{goal.title}</h3>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <span className={`px-2 py-0.5 rounded-full ${
                            goal.priority === 'High' ? 'bg-red-500/10 text-red-500' : 'bg-blue-500/10 text-blue-500'
                          }`}>
                            {goal.priority}
                          </span>
                          <span>Target: {goal.deadline}</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-xl">₹{goal.targetAmount.toLocaleString()}</div>
                      <div className="text-xs text-muted-foreground">{t.target}</div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">{t.savings}: <span className="text-foreground font-medium">₹{goal.currentAmount.toLocaleString()}</span></span>
                      <span className="text-primary font-bold">{Math.round((goal.currentAmount / goal.targetAmount) * 100)}%</span>
                    </div>
                    <Progress value={(goal.currentAmount / goal.targetAmount) * 100} className="h-2" />
                  </div>

                  <div className="mt-4 flex items-center justify-between">
                    <div className="p-2 bg-secondary/30 rounded-lg text-xs text-muted-foreground flex gap-2 items-center">
                      <Trophy size={14} className="text-yellow-500 shrink-0" />
                      <span>Save <span className="text-foreground font-medium">₹3,500/mo</span> to reach by {goal.deadline}.</span>
                    </div>
                    <Button variant="link" size="sm" className="text-primary h-auto p-0" onClick={() => handleViewPlan(goal)}>
                        {t.viewPlan}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* CHALLENGES SECTION */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold font-heading flex items-center gap-2">
              <Trophy className="text-accent" /> {t.challenges}
            </h2>
            
            <Dialog open={isChallengeDialogOpen} onOpenChange={setIsChallengeDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline">
                  <Plus className="mr-2 h-4 w-4" /> {t.joinChallenge}
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-card border-border text-foreground">
                 <DialogHeader>
                   <DialogTitle>{t.joinChallenge}</DialogTitle>
                 </DialogHeader>
                 <div className="grid gap-4 py-4">
                    <div className="grid gap-2">
                       <Label>{t.title}</Label>
                       <Input 
                         placeholder="e.g. No Ordering Out" 
                         value={newChallenge.title}
                         onChange={(e) => setNewChallenge({...newChallenge, title: e.target.value})}
                         className="bg-secondary/50"
                       />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                       <div className="grid gap-2">
                          <Label>Limit</Label>
                          <Input 
                             type="number" 
                             placeholder="3" 
                             value={newChallenge.limit}
                             onChange={(e) => setNewChallenge({...newChallenge, limit: e.target.value})}
                             className="bg-secondary/50"
                          />
                       </div>
                       <div className="grid gap-2">
                          <Label>Unit</Label>
                          <Select 
                            value={newChallenge.unit}
                            onValueChange={(val) => setNewChallenge({...newChallenge, unit: val})}
                          >
                             <SelectTrigger className="bg-secondary/50">
                                <SelectValue />
                             </SelectTrigger>
                             <SelectContent>
                                <SelectItem value="week">Times / Week</SelectItem>
                                <SelectItem value="month">Times / Month</SelectItem>
                                <SelectItem value="rupees">Rupees / Week</SelectItem>
                             </SelectContent>
                          </Select>
                       </div>
                    </div>
                 </div>
                 <DialogFooter>
                    <Button onClick={handleAddChallenge} className="bg-accent text-accent-foreground hover:bg-accent/90">{t.save}</Button>
                 </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid gap-4">
            {challenges.map((challenge) => (
              <Card key={challenge.id} className="border-border bg-card relative overflow-hidden">
                {/* Decorative stripe */}
                <div className={`absolute left-0 top-0 h-full w-1 ${challenge.status === 'On Track' ? 'bg-emerald-500' : 'bg-red-500'}`}></div>
                
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div className="flex gap-3">
                      <div className="bg-secondary p-2 rounded-full h-fit">
                        <Coffee size={20} className="text-muted-foreground" />
                      </div>
                      <div>
                        <h3 className="font-bold">{challenge.title}</h3>
                        <p className="text-sm text-muted-foreground">Limit: {challenge.limit} {challenge.unit}</p>
                      </div>
                    </div>
                    <div className={`px-2.5 py-1 rounded-full text-xs font-medium ${
                       challenge.status === 'On Track' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-red-500/10 text-red-500'
                    }`}>
                      {challenge.status}
                    </div>
                  </div>

                  <div className="mt-4">
                    <div className="flex justify-between text-xs mb-1.5">
                      <span>{t.status}</span>
                      <span>{challenge.spent} / {challenge.limit} used</span>
                    </div>
                    <Progress value={(challenge.spent / challenge.limit) * 100} className={`h-2 ${
                      challenge.status === 'On Track' ? '[&>div]:bg-emerald-500' : '[&>div]:bg-red-500'
                    }`} />
                  </div>
                  
                  <div className="mt-3 flex justify-end">
                     <span className="text-xs font-medium text-accent bg-accent/10 px-2 py-1 rounded flex items-center gap-1">
                       <Plus size={10} /> 20 XP Reward
                     </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

      </div>

      {/* View Plan Modal */}
      <Dialog open={isViewPlanOpen} onOpenChange={setIsViewPlanOpen}>
         <DialogContent className="bg-card border-border text-foreground">
            <DialogHeader>
               <DialogTitle>Saving Plan for {selectedGoal?.title}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-2">
               <div className="flex justify-between p-3 bg-secondary/30 rounded-lg">
                  <span className="text-sm text-muted-foreground">Current Status</span>
                  <span className="font-bold">₹{selectedGoal?.currentAmount} saved</span>
               </div>
               <div className="space-y-2">
                  <h4 className="font-medium text-sm">Recommended Strategy</h4>
                  <ul className="text-sm text-muted-foreground space-y-2 list-disc pl-4">
                     <li>Increase daily savings by ₹50.</li>
                     <li>Allocate 10% of next Zomato payout directly here.</li>
                     <li>Cut 'Eating Out' budget by ₹500 this month.</li>
                  </ul>
               </div>
            </div>
            <DialogFooter>
               <Button onClick={() => setIsViewPlanOpen(false)}>Got it</Button>
            </DialogFooter>
         </DialogContent>
      </Dialog>
    </div>
  );
}
