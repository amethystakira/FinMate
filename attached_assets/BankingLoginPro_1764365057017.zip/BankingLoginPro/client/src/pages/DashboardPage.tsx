import { useState, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { useFinance } from "@/context/FinancialContext";
import { translations } from "@/lib/translations";
import { useSpeechToText } from "@/hooks/useSpeechToText";
import { 
  ArrowUpRight, ArrowDownRight, TrendingUp, AlertCircle, Plus, 
  ChevronRight, UploadCloud, FileText, Search, Filter, Mic, MicOff, Download 
} from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import { incomeStreams, spendingCategories } from "@/lib/mockData";
import { useToast } from "@/hooks/use-toast";

export default function DashboardPage() {
  const { 
    user, updateUser, 
    transactions, addTransaction, 
    goals, challenges, 
    bills, markBillPaid,
    language 
  } = useFinance();
  
  const t = translations[language];
  const { toast } = useToast();
  
  // File Upload
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Modals
  const [isBillsOpen, setIsBillsOpen] = useState(false);
  const [isExpenseOpen, setIsExpenseOpen] = useState(false);
  
  // Expense Form
  const [newExpense, setNewExpense] = useState({ title: "", amount: "", category: "Food", date: new Date().toISOString().split('T')[0] });
  
  // Speech
  const { isListening, transcript, startListening, stopListening, setTranscript } = useSpeechToText();

  // Search & Filter
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategory, setFilterCategory] = useState("All");

  // --- Handlers ---
  
  const handleUploadClick = () => fileInputRef.current?.click();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
       const loadingToast = toast({
          title: t.analyzing,
          description: "Extracting income and expense patterns",
       });
       
       setTimeout(() => {
          loadingToast.dismiss();
          // Mock Parsing
          addTransaction({
            title: "Parsed Bank Stmt - Restaurant",
            amount: 1200,
            category: "Food",
            type: "expense",
            date: new Date().toISOString().split('T')[0]
          });
          
          toast({
             title: t.success,
             description: "Found ₹1,200 Food expense from statement.",
             variant: "default",
             className: "bg-green-600 text-white border-none"
          });
       }, 2000);
    }
  };

  const handleAddExpense = () => {
    if (!newExpense.title || !newExpense.amount) return;
    
    addTransaction({
      title: newExpense.title,
      amount: parseFloat(newExpense.amount),
      category: newExpense.category,
      type: "expense",
      date: newExpense.date
    });
    
    setIsExpenseOpen(false);
    setNewExpense({ title: "", amount: "", category: "Food", date: new Date().toISOString().split('T')[0] });
    setTranscript("");
    
    toast({
      title: t.success,
      description: "Expense added successfully.",
    });
  };

  // Speech Effect for Form Filling
  const handleMicClick = () => {
    if (isListening) {
      stopListening();
      // Simple parser: "Coffee 500"
      const words = transcript.split(" ");
      const amount = words.find(w => !isNaN(parseFloat(w)));
      const text = words.filter(w => isNaN(parseFloat(w))).join(" ");
      
      if (amount) setNewExpense(prev => ({ ...prev, amount, title: text || "Voice Expense" }));
    } else {
      setTranscript("");
      startListening();
    }
  };

  const filteredTransactions = transactions.filter(t => 
    (filterCategory === "All" || t.category === filterCategory) &&
    (t.title.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  // Prepare Chart Data from dynamic transactions
  const chartData = transactions.reduce((acc: any[], curr) => {
    if (curr.type === 'expense') {
      const existing = acc.find(i => i.name === curr.category);
      if (existing) existing.value += curr.amount;
      else acc.push({ name: curr.category, value: curr.amount, color: '#14b8a6' }); // Default color
    }
    return acc;
  }, []);
  
  // Fallback to mock if empty for visual
  const displayChartData = chartData.length > 0 ? chartData : spendingCategories;

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      
      {/* Top Row: KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Income vs Expenses */}
        <Card className="border-border bg-card shadow-lg">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">{t.monthlyOverview}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-end mb-4">
              <div>
                <div className="text-2xl font-bold font-heading">₹{user.monthlyIncome.toLocaleString()}</div>
                <div className="text-xs text-emerald-500 flex items-center gap-1 mt-1">
                  <TrendingUp size={12} /> +12%
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm text-muted-foreground">{t.savings}</div>
                <div className="text-lg font-semibold text-primary font-heading">
                  ₹{(user.monthlyIncome - user.monthlyExpenses).toLocaleString()}
                </div>
              </div>
            </div>
            <Progress value={(user.monthlyExpenses / user.monthlyIncome) * 100} className="h-2 bg-secondary" indicatorClassName="bg-gradient-to-r from-primary to-accent" />
            <div className="flex justify-between text-xs text-muted-foreground mt-2">
              <span>{t.expenses}: ₹{user.monthlyExpenses.toLocaleString()}</span>
              <span>{Math.round((user.monthlyExpenses / user.monthlyIncome) * 100)}%</span>
            </div>
          </CardContent>
        </Card>

        {/* Financial Health Score */}
        <Card className="border-border bg-card shadow-lg relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-primary/10 rounded-full blur-2xl -mr-10 -mt-10"></div>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">{t.financialHealth}</CardTitle>
          </CardHeader>
          <CardContent className="flex items-center justify-between">
            <div>
              <div className="text-4xl font-bold text-primary font-heading">{user.financialHealth}</div>
              <div className="text-sm font-medium text-accent mt-1">{user.financialLevel}</div>
            </div>
            <div className="h-20 w-20 rounded-full border-4 border-secondary flex items-center justify-center relative">
              <div className="absolute inset-0 rounded-full border-4 border-primary border-t-transparent border-l-transparent rotate-45"></div>
              <span className="text-xl font-bold font-heading">B+</span>
            </div>
          </CardContent>
        </Card>

        {/* Upcoming Bills */}
        <Card className="border-border bg-card shadow-lg cursor-pointer hover:border-primary/50 transition-colors" onClick={() => setIsBillsOpen(true)}>
          <CardHeader className="pb-2 flex flex-row items-center justify-between">
            <CardTitle className="text-sm font-medium text-muted-foreground">{t.upcomingBills}</CardTitle>
            <Button variant="ghost" size="icon" className="h-6 w-6"><ChevronRight size={16} /></Button>
          </CardHeader>
          <CardContent className="space-y-3">
            {bills.slice(0, 3).map((bill) => (
              <div key={bill.id} className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full ${bill.status === 'due-soon' || bill.status === 'urgent' ? 'bg-red-500' : 'bg-emerald-500'}`}></div>
                  <span>{bill.title}</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-medium">₹{bill.amount}</span>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${bill.status === 'urgent' ? 'bg-red-500/20 text-red-500' : 'bg-secondary text-muted-foreground'}`}>
                    {bill.dueIn}
                  </span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Expense Management Row */}
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
         <div className="flex gap-2 w-full md:w-auto">
            <div className="relative flex-1 md:w-64">
               <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
               <Input 
                 placeholder={t.search} 
                 className="pl-8 bg-card border-border"
                 value={searchTerm}
                 onChange={(e) => setSearchTerm(e.target.value)}
               />
            </div>
            <Select value={filterCategory} onValueChange={setFilterCategory}>
               <SelectTrigger className="w-[120px] bg-card border-border">
                  <SelectValue placeholder={t.filters} />
               </SelectTrigger>
               <SelectContent>
                  <SelectItem value="All">All</SelectItem>
                  <SelectItem value="Food">Food</SelectItem>
                  <SelectItem value="Transport">Transport</SelectItem>
                  <SelectItem value="Bills">Bills</SelectItem>
               </SelectContent>
            </Select>
         </div>
         <div className="flex gap-2 w-full md:w-auto">
            <Button variant="outline" className="flex-1 md:flex-none">
               <Download size={16} className="mr-2" /> {t.export}
            </Button>
            <Dialog open={isExpenseOpen} onOpenChange={setIsExpenseOpen}>
               <DialogTrigger asChild>
                  <Button className="flex-1 md:flex-none bg-primary text-primary-foreground hover:bg-primary/90 font-bold">
                     <Plus size={16} className="mr-2" /> {t.addExpense}
                  </Button>
               </DialogTrigger>
               <DialogContent className="bg-card border-border text-foreground">
                  <DialogHeader>
                     <DialogTitle>{t.addExpense}</DialogTitle>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                     <div className="flex items-center gap-2 mb-2">
                        <Button 
                          type="button" 
                          variant={isListening ? "destructive" : "secondary"} 
                          className="w-full"
                          onClick={handleMicClick}
                        >
                           {isListening ? <MicOff className="mr-2 animate-pulse" /> : <Mic className="mr-2" />}
                           {isListening ? t.micListening : t.micStart}
                        </Button>
                     </div>
                     {transcript && <p className="text-xs text-muted-foreground italic">"{transcript}"</p>}
                     
                     <div className="grid gap-2">
                        <Label>{t.title}</Label>
                        <Input 
                           value={newExpense.title}
                           onChange={(e) => setNewExpense({...newExpense, title: e.target.value})}
                           className="bg-secondary/50"
                        />
                     </div>
                     <div className="grid gap-2">
                        <Label>{t.amount}</Label>
                        <Input 
                           type="number"
                           value={newExpense.amount}
                           onChange={(e) => setNewExpense({...newExpense, amount: e.target.value})}
                           className="bg-secondary/50"
                        />
                     </div>
                     <div className="grid gap-2">
                        <Label>{t.category}</Label>
                        <Select 
                          value={newExpense.category}
                          onValueChange={(val) => setNewExpense({...newExpense, category: val})}
                        >
                           <SelectTrigger className="bg-secondary/50">
                              <SelectValue />
                           </SelectTrigger>
                           <SelectContent>
                              <SelectItem value="Food">Food</SelectItem>
                              <SelectItem value="Transport">Transport</SelectItem>
                              <SelectItem value="Bills">Bills</SelectItem>
                              <SelectItem value="Misc">Misc</SelectItem>
                           </SelectContent>
                        </Select>
                     </div>
                     <div className="grid gap-2">
                        <Label>{t.date}</Label>
                        <Input 
                           type="date"
                           value={newExpense.date}
                           onChange={(e) => setNewExpense({...newExpense, date: e.target.value})}
                           className="bg-secondary/50"
                        />
                     </div>
                  </div>
                  <DialogFooter>
                     <Button onClick={handleAddExpense}>{t.save}</Button>
                  </DialogFooter>
               </DialogContent>
            </Dialog>
         </div>
      </div>

      {/* Bills Modal */}
      <Dialog open={isBillsOpen} onOpenChange={setIsBillsOpen}>
         <DialogContent className="bg-card border-border text-foreground">
            <DialogHeader>
               <DialogTitle>{t.upcomingBills}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 mt-2">
               {bills.length === 0 ? (
                  <p className="text-center text-muted-foreground py-4">No pending bills!</p>
               ) : bills.map((bill) => (
                  <div key={bill.id} className="flex items-center justify-between p-3 bg-secondary/30 rounded-lg border border-border">
                     <div className="flex items-center gap-3">
                        <div className="p-2 bg-secondary rounded-full">
                           <FileText size={16} />
                        </div>
                        <div>
                           <div className="font-bold">{bill.title}</div>
                           <div className="text-xs text-muted-foreground">Due {bill.dueIn}</div>
                        </div>
                     </div>
                     <div className="text-right">
                        <div className="font-bold">₹{bill.amount}</div>
                        <Button size="sm" variant="outline" className="h-6 text-xs mt-1" onClick={() => markBillPaid(bill.id)}>
                           {t.payNow}
                        </Button>
                     </div>
                  </div>
               ))}
            </div>
         </DialogContent>
      </Dialog>

      {/* Middle Row: Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Spending Breakdown */}
        <Card className="border-border bg-card shadow-lg">
          <CardHeader>
            <CardTitle className="text-base font-heading">{t.spendingCategory}</CardTitle>
          </CardHeader>
          <CardContent className="h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={displayChartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {displayChartData.map((entry: any, index: number) => (
                    <Cell key={`cell-${index}`} fill={entry.color || '#8884d8'} strokeWidth={0} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                  itemStyle={{ color: 'hsl(var(--foreground))' }}
                />
                <Legend verticalAlign="middle" align="right" layout="vertical" iconType="circle" />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Dynamic Transaction List (Replacing Income Streams for now to show tracked expenses) */}
        <Card className="border-border bg-card shadow-lg">
          <CardHeader>
            <div className="flex justify-between items-start">
              <CardTitle className="text-base font-heading">Recent Transactions</CardTitle>
              <span className="text-xs text-muted-foreground bg-secondary px-2 py-1 rounded">Live</span>
            </div>
          </CardHeader>
          <CardContent className="space-y-4 max-h-[250px] overflow-auto">
            {filteredTransactions.length === 0 ? (
               <p className="text-center text-muted-foreground text-sm py-8">No transactions found.</p>
            ) : filteredTransactions.map((tx) => (
              <div key={tx.id} className="space-y-1 border-b border-border/50 pb-2 last:border-0">
                <div className="flex justify-between text-sm">
                  <span className="font-medium">{tx.title}</span>
                  <span className={tx.type === 'expense' ? 'text-red-400' : 'text-emerald-400'}>
                    {tx.type === 'expense' ? '-' : '+'}₹{tx.amount.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between text-xs text-muted-foreground">
                   <span>{tx.category}</span>
                   <span>{tx.date}</span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Bottom Row: Goals, Challenges, Loan */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Goals Snapshot */}
        <Card className="border-border bg-card shadow-lg flex flex-col">
          <CardHeader className="pb-2 flex flex-row items-center justify-between">
            <CardTitle className="text-base font-heading">{t.activeGoals}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 flex-1">
            {goals.slice(0, 2).map((goal) => (
              <div key={goal.id} className="bg-secondary/30 p-3 rounded-lg border border-border">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-medium text-sm">{goal.title}</span>
                  <span className="text-xs text-muted-foreground">{goal.deadline}</span>
                </div>
                <Progress value={(goal.currentAmount / goal.targetAmount) * 100} className="h-1.5 bg-secondary mb-2" />
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">₹{goal.currentAmount.toLocaleString()} / ₹{goal.targetAmount.toLocaleString()}</span>
                  <span className="text-primary font-medium">{Math.round((goal.currentAmount / goal.targetAmount) * 100)}%</span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Challenges Snapshot */}
        <Card className="border-border bg-card shadow-lg flex flex-col">
          <CardHeader className="pb-2 flex flex-row items-center justify-between">
            <CardTitle className="text-base font-heading">{t.challenges}</CardTitle>
            <span className="text-xs font-medium text-accent bg-accent/10 px-2 py-1 rounded">+20 XP</span>
          </CardHeader>
          <CardContent className="space-y-4 flex-1">
            {challenges.slice(0, 2).map((challenge) => (
              <div key={challenge.id} className="flex items-center justify-between p-3 bg-secondary/30 rounded-lg border border-border">
                <div>
                  <div className="font-medium text-sm">{challenge.title}</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    {challenge.spent} / {challenge.limit} {challenge.unit} used
                  </div>
                </div>
                <div className={`px-2 py-1 rounded text-xs font-medium ${
                  challenge.status === 'On Track' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-red-500/10 text-red-500'
                }`}>
                  {challenge.status}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Loan & Eligibility (Mock) */}
        <Card className="border-border bg-card shadow-lg flex flex-col">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-heading">{t.loanEligibility}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 flex-1">
            <div className="bg-gradient-to-br from-indigo-900/50 to-purple-900/50 p-4 rounded-xl border border-indigo-500/30">
              <div className="flex justify-between items-start mb-2">
                <span className="text-xs font-medium text-indigo-300 uppercase tracking-wider">Best Offer</span>
                <span className="bg-indigo-500 text-white text-[10px] px-1.5 py-0.5 rounded">Pre-approved</span>
              </div>
              <div className="text-xl font-bold text-white">₹1,50,000</div>
              <div className="text-xs text-indigo-200 mt-1">@ 11.5% Interest • EMI ₹3,950</div>
            </div>

            <div 
               className="border-2 border-dashed border-border rounded-xl p-4 flex flex-col items-center justify-center text-center hover:bg-secondary/30 transition-colors cursor-pointer group"
               onClick={handleUploadClick}
            >
              <input 
                 type="file" 
                 ref={fileInputRef} 
                 className="hidden" 
                 accept=".pdf,.png,.jpg"
                 onChange={handleFileChange}
              />
              <div className="w-10 h-10 bg-secondary rounded-full flex items-center justify-center mb-2 group-hover:bg-primary/20 group-hover:text-primary transition-colors">
                <UploadCloud size={20} />
              </div>
              <p className="text-sm font-medium">{t.uploadStatement}</p>
              <p className="text-xs text-muted-foreground mt-1">PDF/Images supported</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
