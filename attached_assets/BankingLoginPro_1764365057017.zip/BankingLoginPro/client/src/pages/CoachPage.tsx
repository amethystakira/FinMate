import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { Send, Mic, Sparkles, ChevronDown, HelpCircle, MicOff, Plus, MessageSquare } from "lucide-react";
import { useFinance } from "@/context/FinancialContext";
import { translations } from "@/lib/translations";
import { useSpeechToText } from "@/hooks/useSpeechToText";

export default function CoachPage() {
  const { user, chatSessions, currentSessionId, createNewSession, addMessageToSession, loadSession, language } = useFinance();
  const t = translations[language];
  
  // Local state for current view
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  
  // Speech
  const { isListening, transcript, startListening, stopListening, setTranscript } = useSpeechToText();

  useEffect(() => {
    if (transcript) setInput(transcript);
  }, [transcript]);

  // Get current session
  const currentSession = chatSessions.find(s => s.id === currentSessionId) || { messages: [] };

  const handleMicClick = () => {
    if (isListening) {
      stopListening();
    } else {
      setTranscript("");
      startListening();
    }
  };

  const handleSend = () => {
    if (!input.trim() && !transcript) return;
    const userMsg = input || transcript;
    
    // If no session, create one
    let sessionId = currentSessionId;
    if (!sessionId) {
       createNewSession();
       // Small delay to allow state update (in real app, would return ID)
       // For now, we assume the context updates and we push to the newest
       // This is a simplification for the prototype
       sessionId = Date.now().toString(); // Fallback or sync issue in mock
    }

    // Push User Message
    if (currentSessionId) {
       addMessageToSession(currentSessionId, { sender: 'user', text: userMsg });
    } else {
       // This case handles the very first message if session logic is async/mock
       // In a real app, createSession would return the ID immediately.
    }
    
    setInput("");
    setTranscript("");
    setIsTyping(true);
    
    // AI Response Logic
    setTimeout(() => {
      let responseText = "";
      
      const lowerMsg = userMsg.toLowerCase();
      
      if (lowerMsg.includes("invest") || lowerMsg.includes("plan")) {
         responseText = t.investmentPlan + ":\n\n" +
                        "• **HDFC Bank / ICICI**: Good for SIPs & FDs.\n" +
                        "• **Zerodha / Groww**: Best for Mutual Funds & Gold.\n\n" +
                        t.smartAllocation + ":\n" +
                        "• 40% SIP\n• 20% FD\n• 10% Gold\n• 30% Needs\n\n" +
                        "Contact HDFC: 1800-202-6161";
      } else {
         responseText = "Based on your request, I've analyzed your spending. You can save more by limiting 'Eating Out'. Would you like to set a challenge?";
      }

      if (currentSessionId) {
         addMessageToSession(currentSessionId, { sender: 'ai', text: responseText });
      }
      setIsTyping(false);
    }, 1500);
  };
  
  // Start a new chat if none exists
  useEffect(() => {
    if (!currentSessionId && chatSessions.length === 0) {
       createNewSession();
    } else if (!currentSessionId && chatSessions.length > 0) {
       loadSession(chatSessions[0].id);
    }
  }, [currentSessionId, chatSessions]);

  const formatMessage = (text: string) => {
    return text.split('\n').map((line, i) => (
      <span key={i} className="block min-h-[1.2em]">
        {line.split(/(\*\*.*?\*\*)/g).map((part, j) => 
          part.startsWith('**') && part.endsWith('**') ? 
          <strong key={j} className="font-bold text-foreground/90">{part.slice(2, -2)}</strong> : 
          part
        )}
      </span>
    ));
  };

  return (
    <div className="h-[calc(100vh-8rem)] flex gap-6 animate-in fade-in duration-500">
      
      {/* Left Sidebar - History */}
      <div className="hidden lg:flex flex-col w-64 gap-4 border-r border-border pr-4">
        <Button onClick={createNewSession} className="w-full gap-2 font-bold">
           <Plus size={16} /> {t.newChat}
        </Button>
        
        <div className="font-bold text-sm text-muted-foreground mt-2">{t.chatHistory}</div>
        <ScrollArea className="flex-1">
           <div className="space-y-2">
              {chatSessions.map(session => (
                 <div 
                   key={session.id}
                   onClick={() => loadSession(session.id)}
                   className={`p-3 rounded-lg cursor-pointer transition-colors text-sm truncate ${
                      currentSessionId === session.id ? 'bg-secondary text-foreground' : 'hover:bg-secondary/50 text-muted-foreground'
                   }`}
                 >
                    <div className="font-medium truncate">{session.title}</div>
                    <div className="text-xs opacity-70">{session.date}</div>
                 </div>
              ))}
           </div>
        </ScrollArea>
      </div>

      {/* Main Chat Window */}
      <div className="flex-1 flex flex-col bg-card border border-border rounded-2xl overflow-hidden shadow-2xl">
        
        {/* Chat Header */}
        <div className="p-4 border-b border-border bg-card flex items-center gap-4 sticky top-0 z-10 shadow-sm">
          <div className="relative">
            <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-primary-foreground font-bold text-lg shadow-lg shadow-primary/20">
              N
            </div>
            <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-card rounded-full"></span>
          </div>
          <div>
            <h3 className="font-bold font-heading">Nivi – Your Financial Coach</h3>
            <p className="text-xs text-muted-foreground">Specialised for Gig Workers • Speaks {language.toUpperCase()}</p>
          </div>
        </div>

        {/* Messages Area */}
        <ScrollArea className="flex-1 p-4 md:p-6 bg-secondary/5">
          <div className="space-y-6">
            {currentSession.messages.map((msg) => (
              <div 
                key={msg.id} 
                className={`flex gap-3 ${msg.sender === 'user' ? 'flex-row-reverse' : ''}`}
              >
                <Avatar className="w-8 h-8 mt-1 border border-border">
                  {msg.sender === 'ai' ? (
                     <div className="w-full h-full bg-primary flex items-center justify-center text-primary-foreground font-bold text-xs">N</div>
                  ) : (
                    <AvatarImage src={user.avatar} />
                  )}
                  <AvatarFallback>{msg.sender === 'ai' ? 'AI' : 'ME'}</AvatarFallback>
                </Avatar>
                
                <div className={`max-w-[85%] md:max-w-[75%] p-4 rounded-2xl shadow-sm ${
                  msg.sender === 'user' 
                    ? 'bg-primary text-primary-foreground rounded-tr-none' 
                    : 'bg-card border border-border text-card-foreground rounded-tl-none'
                }`}>
                  <div className="text-sm leading-relaxed space-y-1">
                    {formatMessage(msg.text)}
                  </div>
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex gap-3">
                 <div className="w-8 h-8 mt-1 bg-primary rounded-full flex items-center justify-center text-primary-foreground font-bold text-xs">N</div>
                 <div className="bg-card border border-border p-4 rounded-2xl rounded-tl-none flex gap-1 items-center h-12">
                   <span className="w-2 h-2 bg-muted-foreground/50 rounded-full animate-bounce"></span>
                   <span className="w-2 h-2 bg-muted-foreground/50 rounded-full animate-bounce delay-75"></span>
                   <span className="w-2 h-2 bg-muted-foreground/50 rounded-full animate-bounce delay-150"></span>
                 </div>
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Input Area */}
        <div className="p-4 bg-card border-t border-border">
          <div className="relative flex items-center gap-2">
            <Button 
               variant={isListening ? "destructive" : "ghost"} 
               size="icon" 
               className={isListening ? "animate-pulse" : "text-muted-foreground hover:text-primary"}
               onClick={handleMicClick}
            >
              {isListening ? <MicOff size={20} /> : <Mic size={20} />}
            </Button>
            <Input 
              placeholder={isListening ? t.micListening : t.chatPlaceholder}
              className="flex-1 bg-secondary/50 border-border focus-visible:ring-primary rounded-full px-4 py-6"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            />
            <Button 
              size="icon" 
              className="rounded-full w-10 h-10 bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg shadow-primary/20"
              onClick={handleSend}
            >
              <Send size={18} />
            </Button>
          </div>
        </div>
      </div>

    </div>
  );
}
