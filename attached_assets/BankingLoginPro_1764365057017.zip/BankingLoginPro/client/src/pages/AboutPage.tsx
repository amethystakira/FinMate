import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useFinance } from "@/context/FinancialContext";
import { translations } from "@/lib/translations";
import { Mail, MapPin, Phone, Globe, ShieldCheck, Users, Heart } from "lucide-react";

export default function AboutPage() {
  const { language } = useFinance();
  const t = translations[language];

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-500">
      <div className="text-center space-y-4">
        <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center text-primary-foreground font-bold text-3xl mx-auto shadow-lg shadow-primary/20">
          N
        </div>
        <h1 className="text-4xl font-heading font-bold">Finmate</h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          {t.aboutText}
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <Card className="bg-card border-border hover:border-primary/50 transition-colors">
          <CardContent className="pt-6 text-center space-y-4">
            <div className="w-12 h-12 bg-secondary rounded-full flex items-center justify-center mx-auto text-primary">
              <ShieldCheck size={24} />
            </div>
            <h3 className="font-bold text-lg">Secure & Private</h3>
            <p className="text-sm text-muted-foreground">
              Bank-grade encryption for all your financial data. We never sell your information.
            </p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border hover:border-primary/50 transition-colors">
          <CardContent className="pt-6 text-center space-y-4">
            <div className="w-12 h-12 bg-secondary rounded-full flex items-center justify-center mx-auto text-accent">
              <Users size={24} />
            </div>
            <h3 className="font-bold text-lg">Community First</h3>
            <p className="text-sm text-muted-foreground">
              Built specifically for the unique needs of gig workers, freelancers, and daily earners.
            </p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border hover:border-primary/50 transition-colors">
          <CardContent className="pt-6 text-center space-y-4">
            <div className="w-12 h-12 bg-secondary rounded-full flex items-center justify-center mx-auto text-red-400">
              <Heart size={24} />
            </div>
            <h3 className="font-bold text-lg">Made with Love</h3>
            <p className="text-sm text-muted-foreground">
              Crafted for MumbaiHacks 2025 to solve real financial challenges.
            </p>
          </CardContent>
        </Card>
      </div>

      <Card className="border-border bg-card">
        <CardHeader>
          <CardTitle className="text-center">{t.contact}</CardTitle>
        </CardHeader>
        <CardContent className="grid md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <div className="flex items-center gap-4 p-4 bg-secondary/30 rounded-lg">
              <Mail className="text-primary" />
              <div>
                <div className="font-medium">Email Us</div>
                <div className="text-sm text-muted-foreground">support@finmate.ai</div>
              </div>
            </div>
            <div className="flex items-center gap-4 p-4 bg-secondary/30 rounded-lg">
              <Phone className="text-primary" />
              <div>
                <div className="font-medium">Call Us</div>
                <div className="text-sm text-muted-foreground">+91 98765 43210</div>
              </div>
            </div>
          </div>
          <div className="space-y-4">
            <div className="flex items-center gap-4 p-4 bg-secondary/30 rounded-lg">
              <MapPin className="text-primary" />
              <div>
                <div className="font-medium">Headquarters</div>
                <div className="text-sm text-muted-foreground">Powai, Mumbai, Maharashtra 400076</div>
              </div>
            </div>
            <div className="flex items-center gap-4 p-4 bg-secondary/30 rounded-lg">
              <Globe className="text-primary" />
              <div>
                <div className="font-medium">Website</div>
                <div className="text-sm text-muted-foreground">www.finmate.ai</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
