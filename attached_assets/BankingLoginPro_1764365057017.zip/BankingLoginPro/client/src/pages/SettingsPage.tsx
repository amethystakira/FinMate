import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useFinance } from "@/context/FinancialContext"; // UPDATED
import { translations } from "@/lib/translations"; // UPDATED
import { Shield, Bell, Globe, LogOut, User, Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useState, useRef } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function SettingsPage() {
  const { user, updateUser, language, setLanguage } = useFinance();
  const t = translations[language];
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [avatar, setAvatar] = useState(user.avatar);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
       const objectUrl = URL.createObjectURL(file);
       setAvatar(objectUrl);
       updateUser({ avatar: objectUrl });
       toast({
         title: "Photo Updated",
         description: "Your profile picture has been changed successfully."
       });
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500 max-w-4xl mx-auto">
      <h1 className="text-3xl font-heading font-bold">{t.settings}</h1>

      {/* Profile Section */}
      <Card className="border-border bg-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-xl">
            <User size={24} className="text-primary" /> {t.profile}
          </CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col md:flex-row gap-8 items-center md:items-start">
          <div className="flex flex-col items-center gap-3">
            <div className="relative group cursor-pointer" onClick={triggerFileInput}>
              <Avatar className="w-32 h-32 border-4 border-secondary group-hover:border-primary transition-colors">
                <AvatarImage src={avatar} className="object-cover" />
                <AvatarFallback className="text-4xl font-bold bg-secondary text-secondary-foreground">{user.name[0]}</AvatarFallback>
              </Avatar>
              <div className="absolute inset-0 bg-black/40 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <Upload className="text-white" size={24} />
              </div>
            </div>
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept="image/*" 
              onChange={handlePhotoUpload} 
            />
            <Button variant="outline" size="sm" onClick={triggerFileInput}>Change Photo</Button>
          </div>
          <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-6 w-full">
            <div className="space-y-2">
              <Label>Full Name</Label>
              <Input 
                value={user.fullName} 
                onChange={(e) => updateUser({ fullName: e.target.value, name: e.target.value.split(" ")[0] })}
                className="bg-secondary/50 border-border" 
              />
            </div>
            <div className="space-y-2">
              <Label>Location</Label>
              <Input 
                value={user.location} 
                onChange={(e) => updateUser({ location: e.target.value })}
                className="bg-secondary/50 border-border" 
              />
            </div>
            <div className="space-y-2">
              <Label>Profession</Label>
              <Input 
                 value={user.profession} 
                 onChange={(e) => updateUser({ profession: e.target.value })}
                 className="bg-secondary/50 border-border" 
              />
            </div>
            <div className="space-y-2">
              <Label>Monthly Income (Avg)</Label>
              <Input defaultValue={`₹${user.monthlyIncome}`} className="bg-secondary/50 border-border" disabled />
              <p className="text-xs text-muted-foreground">Calculated from linked accounts</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Preferences */}
      <Card className="border-border bg-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-xl">
             <Globe size={24} className="text-primary" /> Preferences
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
             <div className="space-y-0.5">
               <Label className="text-base">{t.language}</Label>
               <p className="text-sm text-muted-foreground">Choose your preferred language</p>
             </div>
             <Select value={language} onValueChange={(val: any) => setLanguage(val)}>
               <SelectTrigger className="w-[180px] bg-secondary border-border">
                 <SelectValue />
               </SelectTrigger>
               <SelectContent>
                 <SelectItem value="en">English</SelectItem>
                 <SelectItem value="hi">हिन्दी</SelectItem>
                 <SelectItem value="mr">मराठी</SelectItem>
                 <SelectItem value="bn">বাংলা</SelectItem>
               </SelectContent>
             </Select>
          </div>
          
          <div className="h-[1px] bg-border"></div>

          <div className="space-y-4">
             <div className="flex items-center justify-between">
               <div className="space-y-0.5">
                 <Label className="text-base">{t.notifications}</Label>
                 <p className="text-sm text-muted-foreground">Get alerts for upcoming bills and low balances</p>
               </div>
               <Switch defaultChecked />
             </div>
          </div>
        </CardContent>
      </Card>

      {/* Security & Privacy */}
      <Card className="border-border bg-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-xl">
             <Shield size={24} className="text-primary" /> {t.privacy}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
           <div className="bg-secondary/30 p-4 rounded-lg border border-border">
             <h4 className="font-bold text-sm mb-2">Your Data is Secure</h4>
             <ul className="text-xs text-muted-foreground space-y-2 list-disc pl-4">
               <li>End-to-end encryption for all financial data.</li>
               <li>We do not sell your data to third parties.</li>
               <li>Compliant with upcoming data protection regulations.</li>
             </ul>
           </div>
           
           <Button variant="destructive" className="w-full md:w-auto hover:bg-red-700">
             <LogOut className="mr-2 h-4 w-4" /> {t.logout}
           </Button>
        </CardContent>
      </Card>
    </div>
  );
}
