import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CheckCircle, Building2, Wallet } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useFinance } from "@/context/FinancialContext"; // UPDATED

export default function LoginPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { updateUser } = useFinance(); // UPDATED
  const [step, setStep] = useState(1);
  const [isLinked, setIsLinked] = useState(false);
  
  const [formData, setFormData] = useState({
    name: "",
    age: "",
    city: "",
    profession: "",
    salary: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSelectChange = (value: string, name: string) => {
    setFormData({ ...formData, [name]: value });
  };

  const handleLinkBank = () => {
    // Mock linking process
    const loadingToast = toast({
      title: "Connecting...",
      description: "Securely verifying your credentials",
    });
    
    setTimeout(() => {
      setIsLinked(true);
      loadingToast.dismiss();
      toast({
        title: "Success",
        description: "Bank account and UPI linked successfully!",
        variant: "default", 
        className: "bg-green-600 text-white border-none"
      });
    }, 1500);
  };

  const handleSubmit = () => {
    if (step < 2) {
      if (!formData.name || !formData.salary) {
        toast({
          title: "Missing Information",
          description: "Please enter your name and income to proceed.",
          variant: "destructive"
        });
        return;
      }
      setStep(2);
    } else {
      // Final submit
      updateUser({
        name: formData.name.split(" ")[0],
        fullName: formData.name,
        location: formData.city,
        profession: formData.profession,
        monthlyIncome: parseInt(formData.salary) || 0,
      });
      
      setLocation("/dashboard");
      toast({
        title: "Welcome to Finmate!",
        description: "Your profile has been created.",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden -z-10 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-primary/10 rounded-full blur-[120px]"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-accent/10 rounded-full blur-[120px]"></div>
      </div>

      <Card className="w-full max-w-lg border-border/50 bg-card/95 backdrop-blur-sm shadow-2xl">
        <CardHeader className="space-y-1 text-center pb-8">
          <div className="mx-auto w-12 h-12 bg-primary rounded-xl flex items-center justify-center text-primary-foreground font-bold text-xl mb-4 shadow-lg shadow-primary/20">
            N
          </div>
          <CardTitle className="text-2xl font-heading font-bold">
            {step === 1 ? "Create your profile" : "Connect your finances"}
          </CardTitle>
          <CardDescription>
            {step === 1 
              ? "Tell us a bit about yourself to get personalized financial advice." 
              : "Link your accounts to automatically track income and expenses."}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {step === 1 && (
            <div className="space-y-4 animate-in slide-in-from-right-4 fade-in duration-300">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input 
                    id="name" 
                    name="name" 
                    placeholder="Raj Kumar" 
                    value={formData.name} 
                    onChange={handleChange}
                    className="bg-secondary/50 border-border focus-visible:ring-primary"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="age">Age</Label>
                  <Input 
                    id="age" 
                    name="age" 
                    placeholder="28" 
                    type="number"
                    value={formData.age} 
                    onChange={handleChange}
                    className="bg-secondary/50 border-border focus-visible:ring-primary"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="city">City</Label>
                <Select onValueChange={(val) => handleSelectChange(val, "city")}>
                  <SelectTrigger className="bg-secondary/50 border-border focus-visible:ring-primary">
                    <SelectValue placeholder="Select your city" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Mumbai">Mumbai</SelectItem>
                    <SelectItem value="Delhi">Delhi</SelectItem>
                    <SelectItem value="Bangalore">Bangalore</SelectItem>
                    <SelectItem value="Pune">Pune</SelectItem>
                    <SelectItem value="Hyderabad">Hyderabad</SelectItem>
                    <SelectItem value="Chennai">Chennai</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="profession">Profession / Role</Label>
                <Input 
                  id="profession" 
                  name="profession" 
                  placeholder="e.g. Delivery Partner, Freelancer" 
                  value={formData.profession} 
                  onChange={handleChange}
                  className="bg-secondary/50 border-border focus-visible:ring-primary"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="salary">Average Monthly Income (₹)</Label>
                <Input 
                  id="salary" 
                  name="salary" 
                  placeholder="e.g. 35000" 
                  type="number"
                  value={formData.salary} 
                  onChange={handleChange}
                  className="bg-secondary/50 border-border focus-visible:ring-primary"
                />
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6 animate-in slide-in-from-right-4 fade-in duration-300">
              <div className="bg-secondary/30 p-4 rounded-lg border border-border flex items-start gap-4">
                <div className="p-2 bg-blue-500/10 text-blue-500 rounded-lg">
                  <Building2 size={24} />
                </div>
                <div className="flex-1">
                  <h4 className="font-medium text-sm">Bank Account</h4>
                  <p className="text-xs text-muted-foreground mt-1">Connect your primary bank account for income tracking.</p>
                  {isLinked ? (
                    <div className="flex items-center gap-2 mt-3 text-green-500 text-sm font-medium animate-in fade-in">
                      <CheckCircle size={16} /> Linked: HDFC Bank ****4582
                    </div>
                  ) : (
                    <Button variant="outline" size="sm" className="mt-3 w-full" onClick={handleLinkBank}>
                      Link Bank Account
                    </Button>
                  )}
                </div>
              </div>

              <div className="bg-secondary/30 p-4 rounded-lg border border-border flex items-start gap-4">
                <div className="p-2 bg-primary/10 text-primary rounded-lg">
                  <Wallet size={24} />
                </div>
                <div className="flex-1">
                  <h4 className="font-medium text-sm">UPI Apps</h4>
                  <p className="text-xs text-muted-foreground mt-1">Connect GPay, PhonePe, or Paytm for expense tracking.</p>
                   {isLinked ? (
                    <div className="flex items-center gap-2 mt-3 text-green-500 text-sm font-medium animate-in fade-in">
                      <CheckCircle size={16} /> Linked: 3 UPI Apps
                    </div>
                  ) : (
                    <Button variant="outline" size="sm" className="mt-3 w-full" onClick={handleLinkBank}>
                      Connect UPI
                    </Button>
                  )}
                </div>
              </div>
              
              <p className="text-xs text-center text-muted-foreground">
                Your data is encrypted and secure. We only read transaction SMS and bank statements.
              </p>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          {step === 2 ? (
            <Button variant="ghost" onClick={() => setStep(1)}>Back</Button>
          ) : (
            <div></div>
          )}
          <Button className="w-32 bg-primary text-primary-foreground hover:bg-primary/90 font-bold" onClick={handleSubmit}>
            {step === 1 ? "Next" : "Finish"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
