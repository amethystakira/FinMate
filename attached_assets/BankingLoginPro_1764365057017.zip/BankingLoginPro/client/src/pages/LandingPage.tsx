import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle2, ShieldCheck, BarChart3 } from "lucide-react";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-background text-foreground font-sans selection:bg-primary/20">
      {/* Navbar */}
      <nav className="container mx-auto px-6 py-6 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-primary-foreground font-bold text-xl shadow-lg shadow-primary/20">
            N
          </div>
          <span className="text-2xl font-heading font-bold tracking-tight">Finmate</span>
        </div>
        <div className="hidden md:flex gap-8 text-sm font-medium text-muted-foreground">
          <a href="#features" className="hover:text-primary transition-colors">Features</a>
          <a href="#how-it-works" className="hover:text-primary transition-colors">How it Works</a>
          <a href="#about" className="hover:text-primary transition-colors">About</a>
        </div>
        <div className="flex gap-4">
          <Link href="/login">
            <Button variant="ghost" className="text-muted-foreground hover:text-foreground">Login</Button>
          </Link>
          <Link href="/dashboard">
             <Button className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg shadow-primary/20 font-bold">
               Try Demo
             </Button>
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container mx-auto px-6 py-20 md:py-32 text-center relative overflow-hidden">
        {/* Background Glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/20 rounded-full blur-[120px] -z-10 opacity-50"></div>
        
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary/50 border border-secondary-foreground/10 text-primary text-sm font-medium mb-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
          </span>
          AI Financial Coach
        </div>

        <h1 className="text-5xl md:text-7xl font-heading font-extrabold tracking-tight mb-6 max-w-4xl mx-auto leading-tight animate-in fade-in slide-in-from-bottom-8 duration-700 delay-100">
          Financial Stability for <br/>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
            Gig Workers
          </span>
        </h1>
        
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-10 animate-in fade-in slide-in-from-bottom-8 duration-700 delay-200 font-light">
          Finmate is an AI financial coach designed for India’s gig economy. 
          Track irregular income, plan goals, and grow your money with one smart dashboard.
        </p>

        <div className="flex flex-col sm:flex-row justify-center gap-4 animate-in fade-in slide-in-from-bottom-8 duration-700 delay-300">
          <Link href="/login">
            <Button size="lg" className="h-14 px-8 text-lg bg-primary text-primary-foreground hover:bg-primary/90 shadow-xl shadow-primary/20 rounded-full font-bold">
              Get Started
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
          <Link href="/dashboard">
            <Button size="lg" variant="outline" className="h-14 px-8 text-lg border-muted hover:bg-secondary/50 rounded-full">
              View Live Demo
            </Button>
          </Link>
        </div>

        {/* Platform Logos */}
        <div className="mt-20 pt-10 border-t border-border/50">
          <p className="text-sm text-muted-foreground mb-6 font-medium uppercase tracking-widest">Works seamlessly with</p>
          <div className="flex flex-wrap justify-center gap-8 md:gap-16 opacity-70 grayscale hover:grayscale-0 transition-all duration-500">
            {/* Simple text placeholders for logos or SVG icons would go here */}
            <span className="text-xl font-bold flex items-center gap-2 font-heading"><div className="w-6 h-6 bg-orange-500 rounded-full"></div> Swiggy</span>
            <span className="text-xl font-bold flex items-center gap-2 font-heading"><div className="w-6 h-6 bg-red-600 rounded-full"></div> Zomato</span>
            <span className="text-xl font-bold flex items-center gap-2 font-heading"><div className="w-6 h-6 bg-yellow-400 rounded-full"></div> Rapido</span>
            <span className="text-xl font-bold flex items-center gap-2 font-heading"><div className="w-6 h-6 bg-blue-600 rounded-full"></div> Paytm</span>
            <span className="text-xl font-bold flex items-center gap-2 font-heading"><div className="w-6 h-6 bg-green-500 rounded-full"></div> Upwork</span>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-secondary/30 border-y border-border/50">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-card border border-border p-8 rounded-2xl hover:border-primary/50 transition-colors group">
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center text-primary mb-6 group-hover:scale-110 transition-transform">
                <BarChart3 size={24} />
              </div>
              <h3 className="text-xl font-bold mb-3 font-heading">Smart Dashboard</h3>
              <p className="text-muted-foreground leading-relaxed">Visualize your irregular income streams and expenses in one unified view. Know exactly where you stand.</p>
            </div>
            <div className="bg-card border border-border p-8 rounded-2xl hover:border-primary/50 transition-colors group">
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center text-primary mb-6 group-hover:scale-110 transition-transform">
                <CheckCircle2 size={24} />
              </div>
              <h3 className="text-xl font-bold mb-3 font-heading">Goal & Loan Planner</h3>
              <p className="text-muted-foreground leading-relaxed">Set realistic goals like buying a bike or an emergency fund. Get loan eligibility snapshots instantly.</p>
            </div>
            <div className="bg-card border border-border p-8 rounded-2xl hover:border-primary/50 transition-colors group">
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center text-primary mb-6 group-hover:scale-110 transition-transform">
                <ShieldCheck size={24} />
              </div>
              <h3 className="text-xl font-bold mb-3 font-heading">AI Financial Coach</h3>
              <p className="text-muted-foreground leading-relaxed">Chat with Nivi, your personal AI coach. Ask questions in English or Hindi and get personalized advice.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 container mx-auto px-6 text-center">
        <div className="bg-gradient-to-b from-secondary to-card border border-border rounded-3xl p-12 md:p-20 relative overflow-hidden">
           <div className="absolute top-0 right-0 w-64 h-64 bg-accent/10 rounded-full blur-[80px] -z-10"></div>
           <div className="absolute bottom-0 left-0 w-64 h-64 bg-primary/10 rounded-full blur-[80px] -z-10"></div>
           
           <h2 className="text-3xl md:text-5xl font-bold mb-6 font-heading">Ready to take control?</h2>
           <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">Join thousands of gig workers securing their financial future with Finmate.</p>
           <Link href="/login">
             <Button size="lg" className="h-14 px-10 text-lg bg-primary text-primary-foreground hover:bg-primary/90 shadow-xl shadow-primary/20 rounded-full font-bold">
               Create Free Account
             </Button>
           </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-border bg-secondary/20 text-center text-muted-foreground text-sm">
        <p>© 2025 Finmate. Built for India's Gig Economy.</p>
      </footer>
    </div>
  );
}
