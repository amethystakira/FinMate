import React, { createContext, useContext, useState, useEffect } from "react";
import { mockUser, mockTransactions, mockGoals, mockChallenges, upcomingBills } from "@/lib/mockData";
import { Transaction, Goal, Challenge } from "@/lib/mockData";

type UserData = typeof mockUser;

export interface ChatSession {
  id: string;
  title: string;
  date: string;
  messages: { id: number; sender: 'user' | 'ai'; text: string }[];
}

interface FinancialContextType {
  // User Data
  user: UserData;
  updateUser: (data: Partial<UserData>) => void;
  
  // Core Data
  transactions: Transaction[];
  addTransaction: (t: Omit<Transaction, "id">) => void;
  deleteTransaction: (id: string) => void;
  
  goals: Goal[];
  addGoal: (g: Omit<Goal, "id" | "currentAmount">) => void;
  deleteGoal: (id: string) => void;
  updateGoalAmount: (id: string, amount: number) => void;
  
  challenges: Challenge[];
  joinChallenge: (c: Omit<Challenge, "id" | "spent" | "status">) => void;
  
  bills: typeof upcomingBills;
  markBillPaid: (id: string) => void;
  
  // Chat History
  chatSessions: ChatSession[];
  currentSessionId: string | null;
  createNewSession: () => void;
  addMessageToSession: (sessionId: string, message: { sender: 'user' | 'ai'; text: string }) => void;
  loadSession: (id: string) => void;

  // Settings
  language: "en" | "hi" | "mr" | "bn";
  setLanguage: (lang: "en" | "hi" | "mr" | "bn") => void;
}

const FinancialContext = createContext<FinancialContextType | undefined>(undefined);

export function FinancialProvider({ children }: { children: React.ReactNode }) {
  // --- State Initialization ---
  const [user, setUser] = useState<UserData>(() => {
    const saved = localStorage.getItem("finmate_user");
    return saved ? JSON.parse(saved) : mockUser;
  });
  
  const [language, setLanguage] = useState<"en" | "hi" | "mr" | "bn">("en");
  
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem("finmate_transactions");
    return saved ? JSON.parse(saved) : mockTransactions;
  });

  const [goals, setGoals] = useState<Goal[]>(() => {
    const saved = localStorage.getItem("finmate_goals");
    return saved ? JSON.parse(saved) : mockGoals;
  });

  const [challenges, setChallenges] = useState<Challenge[]>(() => {
    const saved = localStorage.getItem("finmate_challenges");
    return saved ? JSON.parse(saved) : mockChallenges;
  });

  const [bills, setBills] = useState<typeof upcomingBills>(() => {
    const saved = localStorage.getItem("finmate_bills");
    return saved ? JSON.parse(saved) : upcomingBills;
  });

  const [chatSessions, setChatSessions] = useState<ChatSession[]>(() => {
    const saved = localStorage.getItem("finmate_chats");
    return saved ? JSON.parse(saved) : [];
  });

  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);

  // --- Persistence Effects ---
  useEffect(() => localStorage.setItem("finmate_user", JSON.stringify(user)), [user]);
  useEffect(() => localStorage.setItem("finmate_transactions", JSON.stringify(transactions)), [transactions]);
  useEffect(() => localStorage.setItem("finmate_goals", JSON.stringify(goals)), [goals]);
  useEffect(() => localStorage.setItem("finmate_challenges", JSON.stringify(challenges)), [challenges]);
  useEffect(() => localStorage.setItem("finmate_bills", JSON.stringify(bills)), [bills]);
  useEffect(() => localStorage.setItem("finmate_chats", JSON.stringify(chatSessions)), [chatSessions]);

  // --- Actions ---
  const updateUser = (data: Partial<UserData>) => setUser(prev => ({ ...prev, ...data }));

  const addTransaction = (t: Omit<Transaction, "id">) => {
    const newT = { ...t, id: Date.now().toString() };
    setTransactions(prev => [newT, ...prev]);
    
    // Update user savings/expenses based on transaction
    if (t.type === 'expense') {
      setUser(prev => ({ ...prev, monthlyExpenses: prev.monthlyExpenses + t.amount }));
    }
  };

  const deleteTransaction = (id: string) => {
    const t = transactions.find(tx => tx.id === id);
    if (t && t.type === 'expense') {
       setUser(prev => ({ ...prev, monthlyExpenses: prev.monthlyExpenses - t.amount }));
    }
    setTransactions(prev => prev.filter(tx => tx.id !== id));
  };

  const addGoal = (g: Omit<Goal, "id" | "currentAmount">) => {
    const newGoal = { ...g, id: Date.now().toString(), currentAmount: 0 };
    setGoals(prev => [...prev, newGoal]);
  };

  const deleteGoal = (id: string) => {
    setGoals(prev => prev.filter(g => g.id !== id));
  };

  const updateGoalAmount = (id: string, amount: number) => {
    setGoals(prev => prev.map(g => g.id === id ? { ...g, currentAmount: g.currentAmount + amount } : g));
  };

  const joinChallenge = (c: Omit<Challenge, "id" | "spent" | "status">) => {
    const newC = { ...c, id: Date.now().toString(), spent: 0, status: 'On Track' as const };
    setChallenges(prev => [...prev, newC]);
  };

  const markBillPaid = (id: string) => {
    setBills(prev => prev.filter(b => b.id !== id));
    // Optionally add as transaction
  };

  // --- Chat Actions ---
  const createNewSession = () => {
    const newSession: ChatSession = {
      id: Date.now().toString(),
      title: "New Conversation",
      date: new Date().toLocaleDateString(),
      messages: []
    };
    setChatSessions(prev => [newSession, ...prev]);
    setCurrentSessionId(newSession.id);
  };

  const addMessageToSession = (sessionId: string, message: { sender: 'user' | 'ai'; text: string }) => {
    setChatSessions(prev => prev.map(session => {
      if (session.id === sessionId) {
        // Update title if it's the first user message
        const newTitle = session.messages.length === 0 && message.sender === 'user' 
          ? (message.text.slice(0, 25) + "...") 
          : session.title;
          
        return {
          ...session,
          title: newTitle,
          messages: [...session.messages, { ...message, id: Date.now() }]
        };
      }
      return session;
    }));
  };

  const loadSession = (id: string) => setCurrentSessionId(id);

  return (
    <FinancialContext.Provider value={{
      user, updateUser,
      transactions, addTransaction, deleteTransaction,
      goals, addGoal, deleteGoal, updateGoalAmount,
      challenges, joinChallenge,
      bills, markBillPaid,
      chatSessions, currentSessionId, createNewSession, addMessageToSession, loadSession,
      language, setLanguage
    }}>
      {children}
    </FinancialContext.Provider>
  );
}

export function useFinance() {
  const context = useContext(FinancialContext);
  if (context === undefined) {
    throw new Error("useFinance must be used within a FinancialProvider");
  }
  return context;
}
