import React, { createContext, useContext, useState, useEffect } from "react";
import { mockUser } from "@/lib/mockData";

type UserData = typeof mockUser;

interface UserContextType {
  user: UserData;
  updateUser: (data: Partial<UserData>) => void;
  language: "en" | "hi";
  setLanguage: (lang: "en" | "hi") => void;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export function UserProvider({ children }: { children: React.ReactNode }) {
  // Initialize from localStorage or mockUser
  const [user, setUser] = useState<UserData>(() => {
    const saved = localStorage.getItem("finmate_user");
    return saved ? JSON.parse(saved) : mockUser;
  });

  const [language, setLanguage] = useState<"en" | "hi">("en");

  useEffect(() => {
    localStorage.setItem("finmate_user", JSON.stringify(user));
  }, [user]);

  const updateUser = (data: Partial<UserData>) => {
    setUser((prev) => ({ ...prev, ...data }));
  };

  return (
    <UserContext.Provider value={{ user, updateUser, language, setLanguage }}>
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error("useUser must be used within a UserProvider");
  }
  return context;
}
