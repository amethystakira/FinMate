import { Link, useLocation } from "wouter";
import { LayoutDashboard, Target, MessageSquare, TrendingUp, Settings, Bell, Globe, Menu, X, Info } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useFinance } from "@/context/FinancialContext";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { translations } from "@/lib/translations";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { user, language, setLanguage } = useFinance();
  const t = translations[language];

  const navItems = [
    { icon: LayoutDashboard, label: t.dashboard, href: "/dashboard" },
    { icon: Target, label: t.goals, href: "/goals" },
    { icon: MessageSquare, label: t.coach, href: "/coach" },
    { icon: TrendingUp, label: t.insights, href: "/insights" },
    { icon: Settings, label: t.settings, href: "/settings" },
    { icon: Info, label: t.about, href: "/about" },
  ];

  const SidebarContent = () => (
    <div className="flex flex-col h-full bg-sidebar text-sidebar-foreground border-r border-sidebar-border">
      <div className="p-6">
        <h1 className="text-2xl font-heading font-bold text-sidebar-primary flex items-center gap-2">
          <div className="w-8 h-8 bg-sidebar-primary text-sidebar-primary-foreground rounded-lg flex items-center justify-center text-lg">
            N
          </div>
          Nivi
        </h1>
        <p className="text-xs text-muted-foreground mt-1 ml-10">Finmate AI Coach</p>
      </div>

      <nav className="flex-1 px-4 space-y-2">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href}>
              <div
                className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all cursor-pointer group ${
                  isActive
                    ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium"
                    : "text-muted-foreground hover:bg-sidebar-accent/50 hover:text-sidebar-accent-foreground"
                }`}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <item.icon size={20} className={isActive ? "text-sidebar-primary" : "group-hover:text-sidebar-primary transition-colors"} />
                {item.label}
              </div>
            </Link>
          );
        })}
      </nav>
    </div>
  );

  return (
    <div className="min-h-screen bg-background text-foreground flex font-sans">
      {/* Desktop Sidebar */}
      <aside className="hidden md:block w-64 shrink-0 fixed h-full z-30">
        <SidebarContent />
      </aside>

      {/* Mobile Sidebar Sheet */}
      <div className="md:hidden fixed top-4 left-4 z-50">
        <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" className="bg-sidebar border-sidebar-border text-sidebar-foreground">
              <Menu size={20} />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="p-0 w-64 border-r-sidebar-border bg-sidebar text-sidebar-foreground">
             <SidebarContent />
          </SheetContent>
        </Sheet>
      </div>

      {/* Main Content */}
      <main className="flex-1 md:ml-64 min-h-screen flex flex-col">
        {/* Topbar */}
        <header className="h-16 border-b border-border bg-card/50 backdrop-blur-md sticky top-0 z-20 flex items-center justify-between px-6">
          <div className="ml-10 md:ml-0">
            <h2 className="text-lg font-medium hidden sm:block font-heading">
              {t.welcome}, {user.name} 👋
            </h2>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-secondary rounded-full text-xs font-medium text-secondary-foreground border border-border">
              <span>{user.profession}</span>
              <span className="w-1 h-1 rounded-full bg-muted-foreground"></span>
              <span className="truncate max-w-[150px]">{user.roles.join(" + ")}</span>
            </div>

            <div className="h-6 w-[1px] bg-border mx-1 hidden sm:block"></div>

            <Select value={language} onValueChange={(val: any) => setLanguage(val)}>
              <SelectTrigger className="h-8 w-[100px] border-none bg-transparent focus:ring-0 text-muted-foreground hover:text-foreground">
                <Globe size={16} className="mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="en">English</SelectItem>
                <SelectItem value="hi">हिन्दी</SelectItem>
                <SelectItem value="mr">मराठी</SelectItem>
                <SelectItem value="bn">বাংলা</SelectItem>
              </SelectContent>
            </Select>

            <Button variant="ghost" size="icon" className="relative text-muted-foreground hover:text-foreground">
              <Bell size={20} />
              <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>
            </Button>

            <Avatar className="h-8 w-8 border border-border">
              <AvatarImage src={user.avatar} alt={user.name} />
              <AvatarFallback className="bg-primary text-primary-foreground">{user.name[0]}</AvatarFallback>
            </Avatar>
          </div>
        </header>

        {/* Page Content */}
        <div className="flex-1 p-4 md:p-8 overflow-auto">
          {children}
        </div>
      </main>
    </div>
  );
}
