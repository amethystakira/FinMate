import { LucideIcon, CheckCircle2, AlertCircle, TrendingUp, TrendingDown } from "lucide-react";

export interface Transaction {
  id: string;
  title: string;
  amount: number;
  date: string;
  category: string;
  type: 'income' | 'expense';
}

export interface Goal {
  id: string;
  title: string;
  targetAmount: number;
  currentAmount: number;
  deadline: string;
  priority: 'Low' | 'Medium' | 'High';
}

export interface Challenge {
  id: string;
  title: string;
  limit: number;
  spent: number;
  unit: string;
  status: 'On Track' | 'Warning' | 'Failed' | 'Completed';
}

export const mockUser = {
  name: "Raj",
  fullName: "Raj Kumar",
  location: "Pune, India",
  profession: "Gig Worker",
  roles: ["Swiggy", "Zomato", "Freelance Design"],
  avatar: "https://i.pravatar.cc/150?u=raj",
  financialHealth: 62,
  financialLevel: "Bronze Saver",
  monthlyIncome: 42500,
  monthlyExpenses: 35700,
  savings: 6800,
  savingsGrowth: 12.5, // percentage
};

export const mockTransactions: Transaction[] = [
  { id: '1', title: 'Swiggy Payout', amount: 4500, date: '2025-11-27', category: 'Income', type: 'income' },
  { id: '2', title: 'Petrol', amount: 350, date: '2025-11-27', category: 'Transport', type: 'expense' },
  { id: '3', title: 'Zomato Payout', amount: 3200, date: '2025-11-26', category: 'Income', type: 'income' },
  { id: '4', title: 'Grocery Store', amount: 850, date: '2025-11-26', category: 'Food', type: 'expense' },
  { id: '5', title: 'Mobile Recharge', amount: 399, date: '2025-11-25', category: 'Bills', type: 'expense' },
];

export const mockGoals: Goal[] = [
  { id: '1', title: 'Buy Bike', targetAmount: 80000, currentAmount: 12000, deadline: 'March 2026', priority: 'High' },
  { id: '2', title: 'Emergency Fund', targetAmount: 30000, currentAmount: 5000, deadline: '6 months', priority: 'Medium' },
];

export const mockChallenges: Challenge[] = [
  { id: '1', title: 'Coffee Cap', limit: 100, spent: 45, unit: 'week', status: 'On Track' },
  { id: '2', title: 'No-Swiggy Sunday', limit: 4, spent: 2, unit: 'Sundays', status: 'On Track' },
];

export const upcomingBills = [
  { id: '1', title: 'Electricity Bill', amount: 1200, dueIn: '3 days', status: 'due-soon' },
  { id: '2', title: 'EMI', amount: 3500, dueIn: '6 days', status: 'upcoming' },
  { id: '3', title: 'Phone Recharge', amount: 399, dueIn: 'Tomorrow', status: 'urgent' },
];

export const spendingCategories = [
  { name: 'Food & Delivery', value: 12000, color: '#14b8a6' }, // Teal
  { name: 'Transport', value: 8500, color: '#8b5cf6' }, // Purple
  { name: 'Rent & Bills', value: 10000, color: '#06b6d4' }, // Cyan
  { name: 'Subscriptions', value: 1200, color: '#f43f5e' }, // Rose
  { name: 'Misc', value: 4000, color: '#64748b' }, // Slate
];

export const incomeStreams = [
  { name: 'Swiggy', value: 18000 },
  { name: 'Zomato', value: 12500 },
  { name: 'Freelance', value: 12000 },
];
