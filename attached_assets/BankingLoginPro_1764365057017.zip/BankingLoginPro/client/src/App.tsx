import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { FinancialProvider } from "@/context/FinancialContext";
import NotFound from "@/pages/not-found";
import LandingPage from "@/pages/LandingPage";
import LoginPage from "@/pages/LoginPage";
import DashboardPage from "@/pages/DashboardPage";
import GoalsPage from "@/pages/GoalsPage";
import CoachPage from "@/pages/CoachPage";
import InsightsPage from "@/pages/InsightsPage";
import SettingsPage from "@/pages/SettingsPage";
import AboutPage from "@/pages/AboutPage";
import Layout from "@/components/Layout";

// Wrapper to apply Layout only to authenticated pages
const AuthenticatedLayout = ({ component: Component }: { component: React.ComponentType }) => (
  <Layout>
    <Component />
  </Layout>
);

function Router() {
  return (
    <Switch>
      <Route path="/" component={LandingPage} />
      <Route path="/login" component={LoginPage} />
      
      {/* Authenticated Routes */}
      <Route path="/dashboard">
        {() => <AuthenticatedLayout component={DashboardPage} />}
      </Route>
      <Route path="/goals">
        {() => <AuthenticatedLayout component={GoalsPage} />}
      </Route>
      <Route path="/coach">
        {() => <AuthenticatedLayout component={CoachPage} />}
      </Route>
      <Route path="/insights">
        {() => <AuthenticatedLayout component={InsightsPage} />}
      </Route>
      <Route path="/settings">
        {() => <AuthenticatedLayout component={SettingsPage} />}
      </Route>
      <Route path="/about">
        {() => <AuthenticatedLayout component={AboutPage} />}
      </Route>
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <FinancialProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </FinancialProvider>
    </QueryClientProvider>
  );
}

export default App;
