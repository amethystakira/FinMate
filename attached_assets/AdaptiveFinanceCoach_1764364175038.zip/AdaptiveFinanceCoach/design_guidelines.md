# Design Guidelines: AI-Powered Financial Coaching Platform

## Design Approach
**Design System Approach: Material Design 3** - Selected for its robust data visualization patterns, clear information hierarchy, and proven effectiveness in financial/productivity applications. Material Design provides the structured framework needed for complex financial data while maintaining approachability.

## Core Design Principles
1. **Trust & Clarity**: Financial data demands precision and transparency
2. **Scannable Information**: Users need quick insights at a glance
3. **Progressive Disclosure**: Complex features revealed contextually
4. **Contextual Guidance**: AI assistance integrated naturally into workflows

---

## Typography System

**Font Family**: Inter (Google Fonts) for UI, Roboto Mono for financial figures
- **Display/Hero**: 32px/40px, font-weight 700 (dashboard headers)
- **H1**: 24px/32px, font-weight 600 (section headers)
- **H2**: 20px/28px, font-weight 600 (card titles)
- **H3**: 16px/24px, font-weight 500 (subsection headers)
- **Body**: 14px/20px, font-weight 400 (primary content)
- **Small/Caption**: 12px/16px, font-weight 400 (labels, metadata)
- **Financial Figures**: Roboto Mono 16px/24px, font-weight 500 (amounts, calculations)

---

## Layout System

**Spacing Units**: Tailwind units of 2, 4, 6, and 8 for consistent rhythm
- Micro spacing: p-2, gap-2 (8px)
- Component spacing: p-4, gap-4 (16px)
- Section spacing: p-6, gap-6 (24px)
- Major spacing: p-8, mt-8 (32px)

**Grid System**:
- Desktop: 12-column grid with max-w-7xl container
- Dashboard cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Main layout: Sidebar (240px fixed) + Main content (flex-1)
- Mobile: Single column stack with bottom navigation

**Container Patterns**:
- Dashboard: Full-width with px-6 py-8
- Forms/Cards: max-w-2xl for focused interactions
- Chat interface: max-w-4xl centered

---

## Component Library

### Navigation
**Top Bar**: Fixed header with logo, search, notifications, profile (h-16, shadow-sm)
**Sidebar** (Desktop): 240px fixed width, collapsible
- Dashboard, Expenses, Budget, Goals, Loans, AI Coach, Settings
- Active state: subtle background highlight
**Bottom Nav** (Mobile): 5 primary actions, icon + label

### Dashboard Cards
**Card Structure**: 
- Container: rounded-lg, shadow-sm, p-6, bg-white
- Header: flex justify-between items-center, mb-4
- Content: Data visualization or key metrics
- Footer (optional): Actions or "View details" link

**Card Variants**:
- **Stat Card**: Large number + label + trend indicator (↑ 12%)
- **Chart Card**: Header + visualization area (h-64)
- **List Card**: Scrollable transaction list (max-h-80)
- **Quick Action Card**: Icon + title + description + button

### Data Visualizations
**Charts** (Chart.js or Recharts):
- Line charts: Income/expense trends over time
- Donut charts: Expense category distribution
- Bar charts: Monthly comparisons
- Progress bars: Goal achievement, budget usage

**Financial Health Score**: 
- Large circular progress indicator (120px diameter)
- Score number inside (32px bold)
- Color-coded segments: Red (0-40), Yellow (41-70), Green (71-100)
- Gamified level badge below

### Forms & Inputs
**Input Fields**:
- Height: h-12, rounded-md, border focus:ring-2
- Labels: mb-2, font-weight 500
- Helper text: text-sm, text-gray-600
- Error states: border-red-500, text-red-600

**Expense Entry**:
- Amount input: Large, prominent (text-2xl)
- Category selector: Grid of icons or dropdown
- Date picker: Calendar UI
- Voice button: Microphone icon with pulse animation when active

### AI Chat Interface
**Chat Container**: Fixed height (h-96 or h-screen on mobile), flex flex-col
**Message Bubbles**:
- User: ml-auto, max-w-md, rounded-lg p-4, text-white
- AI: mr-auto, max-w-md, rounded-lg p-4, border
- Avatar: 32px circle for AI bot
**Input Area**: Fixed bottom, textarea + send button, mic button for voice

### Notifications & Alerts
**Toast Notifications**: Fixed top-right, slide-in animation
- Success: Green accent, checkmark icon
- Warning: Amber accent, alert icon
- Info: Blue accent, info icon
**Smart Nudges**: Subtle banner at dashboard top, dismissible

### Buttons
**Primary**: Full rounded-md, px-6 py-3, font-weight 500
**Secondary**: Outlined version of primary
**Icon Button**: 40px square, rounded-full
**FAB** (Mobile): Fixed bottom-right for quick expense entry

### Modals & Overlays
**Modal**: max-w-2xl, rounded-lg, shadow-2xl, p-8
**Drawer** (Mobile): Slide from bottom, rounded-t-2xl
**Backdrop**: Semi-transparent dark overlay

---

## Page Layouts

### Dashboard (Home)
- Welcome header with user name + date
- Financial health score card (prominent, top-left)
- 3-column grid: Income this month, Expenses, Savings rate
- Expense breakdown chart (full width)
- Recent transactions list (2 columns on desktop)
- Quick actions: Add expense, Set goal, Chat with AI

### Expenses Page
- Filter bar: Date range, categories, search
- Category distribution donut chart
- Monthly trend line chart
- Transaction list with infinite scroll
- Floating action button: Add expense

### Budget Planner
- Monthly budget overview card
- Category budget cards in grid (Food, Transport, etc.)
- Each card shows: Allocated budget, spent amount, progress bar
- Alert badges for categories over 80%
- Suggested adjustments from AI

### Goals Tracker
- Grid of goal cards (2 columns desktop, 1 mobile)
- Each card: Goal name, target amount, current progress (circular), deadline
- "Add new goal" card with + icon
- AI suggestions for micro-saving

### Loan Comparison
- Filter/sort controls at top
- Table view on desktop, card stack on mobile
- Columns: Bank, Interest rate, EMI, Total cost
- Highlight best option
- Expandable rows for details

### AI Chat Coach
- Full-screen chat interface (or slide-out panel on desktop)
- Quick action chips: "Check budget", "Analyze spending", "Tax estimate"
- Context cards within chat (show relevant data inline)
- Voice waveform visualization when recording

---

## Animations
**Minimal, Purposeful Only**:
- Card hover: subtle shadow increase (transition-shadow)
- Number counters: Animate on mount (financial figures)
- Chart loading: Fade-in, no complex transitions
- Chat messages: Simple slide-up on new message
- NO scroll-triggered animations
- NO decorative motion

---

## Images
**Hero Section**: NOT applicable (dashboard application)
**Illustrations**:
- Empty states: Use Undraw or similar (financial illustrations)
- Onboarding: 3-4 simple illustrations for feature intro
- AI chat avatar: Friendly robot/assistant icon
**No stock photos** - this is a data-focused application

---

## Responsive Breakpoints
- Mobile: base (320px+)
- Tablet: md: (768px+)
- Desktop: lg: (1024px+)
- Wide: xl: (1280px+)

**Mobile-First Adaptations**:
- Sidebar converts to bottom navigation
- 3-column grids stack to 1 column
- Charts reduce height (h-48 instead of h-64)
- Tables convert to card lists
- Fixed headers collapse to hamburger menu