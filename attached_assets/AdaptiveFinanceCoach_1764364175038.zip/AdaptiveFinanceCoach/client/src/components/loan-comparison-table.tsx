import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface Loan {
  id: string;
  bank: string;
  interestRate: number;
  emi: number;
  totalCost: number;
  tenure: number;
  isBest?: boolean;
}

interface LoanComparisonTableProps {
  loans: Loan[];
}

export function LoanComparisonTable({ loans }: LoanComparisonTableProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Loan Comparison</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Bank</TableHead>
                <TableHead>Interest Rate</TableHead>
                <TableHead>EMI</TableHead>
                <TableHead>Tenure</TableHead>
                <TableHead>Total Cost</TableHead>
                <TableHead className="text-right">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loans.map((loan) => (
                <TableRow key={loan.id} data-testid={`loan-row-${loan.id}`}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      {loan.bank}
                      {loan.isBest && (
                        <Badge variant="default" className="bg-chart-2">Best</Badge>
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="font-mono">{loan.interestRate.toFixed(2)}%</TableCell>
                  <TableCell className="font-mono">₹{loan.emi.toLocaleString()}</TableCell>
                  <TableCell>{loan.tenure} months</TableCell>
                  <TableCell className="font-mono">₹{loan.totalCost.toLocaleString()}</TableCell>
                  <TableCell className="text-right">
                    <Button variant="outline" size="sm" data-testid={`button-apply-${loan.id}`}>
                      Apply
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
