import { Card, CardContent } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";

interface QuickActionCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  onClick: () => void;
  gradient?: string;
  testId?: string;
}

export function QuickActionCard({ 
  icon: Icon, 
  title, 
  description, 
  onClick,
  gradient = "from-primary/10 to-primary/5",
  testId 
}: QuickActionCardProps) {
  return (
    <Card
      className="group hover-elevate active-elevate-2 cursor-pointer transition-all duration-200 border-0 bg-gradient-to-br"
      style={{ backgroundImage: `linear-gradient(to bottom right, var(--tw-gradient-stops))` }}
      onClick={onClick}
      data-testid={testId}
    >
      <CardContent className="p-6">
        <div className="flex items-start gap-4">
          <div className="p-3 rounded-xl bg-primary text-primary-foreground shadow-lg group-hover:scale-110 transition-transform">
            <Icon className="h-6 w-6" />
          </div>
          <div className="flex-1 space-y-1">
            <h3 className="font-semibold text-lg">{title}</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">{description}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
