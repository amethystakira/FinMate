import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sparkles, TrendingUp } from "lucide-react";

interface WelcomeBannerProps {
  userName?: string;
  financialHealth: number;
  insight: string;
}

export function WelcomeBanner({ userName = "there", financialHealth, insight }: WelcomeBannerProps) {
  return (
    <Card className="relative overflow-hidden bg-gradient-to-br from-primary via-primary to-primary/80 text-primary-foreground border-0">
      <div className="absolute inset-0 bg-grid-white/[0.05] bg-[size:20px_20px]" />
      <div className="relative p-8">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 space-y-4">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tight">
                Welcome back, {userName}! 👋
              </h1>
              <p className="text-primary-foreground/80 text-lg">
                Your financial health score is <span className="font-bold">{financialHealth}/100</span>
              </p>
            </div>
            
            <div className="flex items-start gap-3 p-4 rounded-lg bg-white/10 backdrop-blur-sm">
              <Sparkles className="h-5 w-5 mt-0.5 flex-shrink-0" />
              <div className="flex-1">
                <p className="text-sm font-medium mb-1">Today's Insight</p>
                <p className="text-sm text-primary-foreground/90">{insight}</p>
              </div>
            </div>

            <div className="flex gap-3">
              <Button 
                variant="secondary" 
                className="bg-white text-primary hover:bg-white/90"
                data-testid="button-view-insights"
              >
                <TrendingUp className="h-4 w-4 mr-2" />
                View Full Report
              </Button>
            </div>
          </div>

          <div className="hidden lg:flex items-center justify-center w-32 h-32">
            <div className="relative">
              <div className="absolute inset-0 bg-white/20 rounded-full animate-ping" />
              <div className="relative flex items-center justify-center w-24 h-24 bg-white/10 backdrop-blur-sm rounded-full border-4 border-white/20">
                <span className="text-3xl font-bold">{financialHealth}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}
