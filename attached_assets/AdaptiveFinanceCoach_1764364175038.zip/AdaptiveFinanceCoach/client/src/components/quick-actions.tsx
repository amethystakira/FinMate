import { Card, CardContent } from "@/components/ui/card";
import { Plus, Target, MessageSquare } from "lucide-react";

interface QuickAction {
  icon: React.ReactNode;
  title: string;
  description: string;
  onClick: () => void;
}

export function QuickActions() {
  const actions: QuickAction[] = [
    {
      icon: <Plus className="h-6 w-6" />,
      title: "Add Expense",
      description: "Log a new transaction",
      onClick: () => console.log("Add expense clicked"),
    },
    {
      icon: <Target className="h-6 w-6" />,
      title: "Set Goal",
      description: "Create financial target",
      onClick: () => console.log("Set goal clicked"),
    },
    {
      icon: <MessageSquare className="h-6 w-6" />,
      title: "Ask AI Coach",
      description: "Get personalized advice",
      onClick: () => console.log("AI coach clicked"),
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {actions.map((action, index) => (
        <Card
          key={index}
          className="hover-elevate active-elevate-2 cursor-pointer transition-all"
          onClick={action.onClick}
          data-testid={`quick-action-${action.title.toLowerCase().replace(/\s+/g, '-')}`}
        >
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="p-3 rounded-md bg-primary text-primary-foreground">
                {action.icon}
              </div>
              <div className="flex-1">
                <h3 className="font-semibold mb-1">{action.title}</h3>
                <p className="text-sm text-muted-foreground">{action.description}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
