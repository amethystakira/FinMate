import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Trophy } from "lucide-react";

interface ChallengeCardProps {
  id: string;
  category: string;
  limit: number;
  spent: number;
  period: string;
  daysLeft: number;
  active: boolean;
}

export function ChallengeCard({ 
  id,
  category, 
  limit, 
  spent, 
  period,
  daysLeft,
  active 
}: ChallengeCardProps) {
  const percentage = (spent / limit) * 100;
  const isSuccess = percentage <= 100 && daysLeft === 0;
  const isFailing = percentage > 100;

  return (
    <Card data-testid={`challenge-card-${id}`}>
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-3">
        <CardTitle className="text-base font-semibold flex items-center gap-2">
          <Trophy className="h-4 w-4" />
          {category} Challenge
        </CardTitle>
        {active && <Badge variant="default">Active</Badge>}
        {isSuccess && <Badge variant="default" className="bg-chart-2">Success!</Badge>}
        {isFailing && <Badge variant="destructive">Failed</Badge>}
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Limit: ₹{limit.toFixed(0)}</span>
            <span className="font-semibold">Spent: ₹{spent.toFixed(0)}</span>
          </div>
          <Progress 
            value={Math.min(percentage, 100)} 
            className="h-2"
          />
        </div>
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>{period}</span>
          {active && <span>{daysLeft} days left</span>}
        </div>
        {percentage <= 100 && active && (
          <p className="text-xs text-chart-2 font-medium">
            ₹{(limit - spent).toFixed(0)} remaining - You're doing great!
          </p>
        )}
      </CardContent>
    </Card>
  );
}
