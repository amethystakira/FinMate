import { ChatMessage } from '../chat-message'

export default function ChatMessageExample() {
  return (
    <div className="space-y-4 p-4 bg-background">
      <ChatMessage 
        role="user" 
        content="How can I reduce my monthly expenses?" 
      />
      <ChatMessage 
        role="assistant" 
        content="Based on your spending pattern, I notice you spend ₹8,500 on food monthly. Here are some tips to reduce this:\n\n1. Cook more meals at home\n2. Plan your weekly grocery shopping\n3. Reduce dining out from 12 to 8 times per month\n\nThis could save you ₹2,000-3,000 monthly!" 
      />
    </div>
  )
}
