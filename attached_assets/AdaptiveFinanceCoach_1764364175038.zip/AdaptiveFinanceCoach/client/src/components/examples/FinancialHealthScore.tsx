import { FinancialHealthScore } from '../financial-health-score'

export default function FinancialHealthScoreExample() {
  return <FinancialHealthScore score={78} level="Gold Saver" />
}
