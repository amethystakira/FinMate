import { LoanComparisonTable } from '../loan-comparison-table'

export default function LoanComparisonTableExample() {
  const loans = [
    { id: '1', bank: 'HDFC Bank', interestRate: 8.5, emi: 15234, totalCost: 914040, tenure: 60, isBest: true },
    { id: '2', bank: 'SBI', interestRate: 8.75, emi: 15456, totalCost: 927360, tenure: 60 },
    { id: '3', bank: 'ICICI Bank', interestRate: 9.0, emi: 15678, totalCost: 940680, tenure: 60 },
    { id: '4', bank: 'Axis Bank', interestRate: 9.25, emi: 15901, totalCost: 954060, tenure: 60 },
  ]
  
  return <LoanComparisonTable loans={loans} />
}
