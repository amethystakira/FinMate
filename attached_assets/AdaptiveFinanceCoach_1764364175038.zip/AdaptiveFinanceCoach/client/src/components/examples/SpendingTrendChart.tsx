import { SpendingTrendChart } from '../spending-trend-chart'

export default function SpendingTrendChartExample() {
  const data = [
    { month: 'Jan', income: 45000, expenses: 32000 },
    { month: 'Feb', income: 47000, expenses: 34500 },
    { month: 'Mar', income: 46000, expenses: 31000 },
    { month: 'Apr', income: 48000, expenses: 35500 },
    { month: 'May', income: 50000, expenses: 33000 },
    { month: 'Jun', income: 45000, expenses: 32500 },
  ]
  
  return <SpendingTrendChart data={data} />
}
