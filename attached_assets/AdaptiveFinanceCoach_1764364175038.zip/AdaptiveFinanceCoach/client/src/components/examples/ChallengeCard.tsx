import { ChallengeCard } from '../challenge-card'

export default function ChallengeCardExample() {
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <ChallengeCard 
        id="1"
        category="Coffee" 
        limit={500} 
        spent={320} 
        period="This Week"
        daysLeft={3}
        active={true}
      />
      <ChallengeCard 
        id="2"
        category="Dining Out" 
        limit={2000} 
        spent={1850} 
        period="This Month"
        daysLeft={10}
        active={true}
      />
    </div>
  )
}
