import { ModernExpenseEntry } from '../modern-expense-entry'

export default function ModernExpenseEntryExample() {
  return (
    <div className="max-w-2xl p-6 bg-background">
      <ModernExpenseEntry
        onSave={(expense) => console.log("Expense saved:", expense)}
      />
    </div>
  )
}
