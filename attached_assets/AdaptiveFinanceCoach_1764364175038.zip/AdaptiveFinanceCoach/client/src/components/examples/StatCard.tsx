import { StatCard } from '../stat-card'
import { DollarSign } from 'lucide-react'

export default function StatCardExample() {
  return (
    <div className="grid gap-4 md:grid-cols-3">
      <StatCard 
        title="Income This Month" 
        value="₹45,000" 
        trend={12} 
        icon={DollarSign}
      />
      <StatCard 
        title="Expenses This Month" 
        value="₹32,500" 
        trend={-5} 
        icon={DollarSign}
      />
      <StatCard 
        title="Savings Rate" 
        value="28%" 
        trend={8} 
        icon={DollarSign}
      />
    </div>
  )
}
