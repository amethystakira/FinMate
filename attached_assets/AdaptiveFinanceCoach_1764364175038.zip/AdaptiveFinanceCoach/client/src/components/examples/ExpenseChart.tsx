import { ExpenseChart } from '../expense-chart'

export default function ExpenseChartExample() {
  const data = [
    { category: 'Food', amount: 8500, color: 'hsl(var(--chart-1))' },
    { category: 'Transport', amount: 4200, color: 'hsl(var(--chart-2))' },
    { category: 'Shopping', amount: 6800, color: 'hsl(var(--chart-3))' },
    { category: 'Bills', amount: 5500, color: 'hsl(var(--chart-4))' },
    { category: 'Entertainment', amount: 3200, color: 'hsl(var(--chart-5))' },
  ]
  
  return <ExpenseChart data={data} />
}
