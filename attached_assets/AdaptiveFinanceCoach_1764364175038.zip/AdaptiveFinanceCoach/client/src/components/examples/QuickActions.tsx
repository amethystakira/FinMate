import { QuickActions } from '../quick-actions'

export default function QuickActionsExample() {
  return <QuickActions />
}
