import { WelcomeBanner } from '../welcome-banner'

export default function WelcomeBannerExample() {
  return (
    <div className="p-6 bg-background">
      <WelcomeBanner
        userName="Rahul"
        financialHealth={78}
        insight="You've saved 15% more this month! Keep up the great work and you'll reach your emergency fund goal by December."
      />
    </div>
  )
}
