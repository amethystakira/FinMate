import { GoalCard } from '../goal-card'

export default function GoalCardExample() {
  return (
    <div className="grid gap-4 md:grid-cols-3">
      <GoalCard 
        id="1"
        name="Emergency Fund" 
        targetAmount={50000} 
        currentAmount={32000} 
        deadline="Dec 2025"
        onAddMoney={(id) => console.log('Add money to goal:', id)}
      />
      <GoalCard 
        id="2"
        name="New Laptop" 
        targetAmount={80000} 
        currentAmount={45000} 
        deadline="Mar 2026"
        onAddMoney={(id) => console.log('Add money to goal:', id)}
      />
      <GoalCard 
        id="3"
        name="Vacation Trip" 
        targetAmount={60000} 
        currentAmount={18000} 
        deadline="Jun 2026"
        onAddMoney={(id) => console.log('Add money to goal:', id)}
      />
    </div>
  )
}
