import { RecentTransactions } from '../recent-transactions'

export default function RecentTransactionsExample() {
  const transactions = [
    { id: '1', description: 'Grocery Shopping', category: 'Food', amount: 2500, date: '2 hours ago' },
    { id: '2', description: 'Uber Ride', category: 'Transport', amount: 350, date: '5 hours ago' },
    { id: '3', description: 'Coffee', category: 'Coffee', amount: 180, date: 'Yesterday' },
    { id: '4', description: 'Electricity Bill', category: 'Bills', amount: 1800, date: 'Yesterday' },
    { id: '5', description: 'Amazon Purchase', category: 'Shopping', amount: 4200, date: '2 days ago' },
    { id: '6', description: 'Restaurant', category: 'Food', amount: 1200, date: '3 days ago' },
  ]
  
  return <RecentTransactions transactions={transactions} />
}
