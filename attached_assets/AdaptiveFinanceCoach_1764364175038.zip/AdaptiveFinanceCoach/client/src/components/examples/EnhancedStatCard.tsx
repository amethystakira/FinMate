import { EnhancedStatCard } from '../enhanced-stat-card'
import { DollarSign, TrendingUp, Wallet, PiggyBank } from 'lucide-react'

export default function EnhancedStatCardExample() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 p-6 bg-background">
      <EnhancedStatCard 
        title="Total Balance" 
        value="₹1,24,500" 
        trend={12} 
        icon={Wallet}
        subtitle="Across all accounts"
      />
      <EnhancedStatCard 
        title="Monthly Income" 
        value="₹45,000" 
        trend={5} 
        icon={DollarSign}
        subtitle="This month"
      />
      <EnhancedStatCard 
        title="Monthly Expenses" 
        value="₹32,500" 
        trend={-8} 
        icon={TrendingUp}
        subtitle="28% less than last month"
      />
      <EnhancedStatCard 
        title="Total Savings" 
        value="₹12,500" 
        trend={15} 
        icon={PiggyBank}
        subtitle="This month"
      />
    </div>
  )
}
