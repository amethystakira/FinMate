import { QuickActionCard } from '../quick-action-card'
import { Plus, Target, MessageSquare } from 'lucide-react'

export default function QuickActionCardExample() {
  return (
    <div className="grid gap-4 md:grid-cols-3 p-6 bg-background">
      <QuickActionCard
        icon={Plus}
        title="Add Expense"
        description="Log a new transaction quickly"
        onClick={() => console.log("Add expense")}
      />
      <QuickActionCard
        icon={Target}
        title="Track Goals"
        description="Monitor your financial targets"
        onClick={() => console.log("Track goals")}
      />
      <QuickActionCard
        icon={MessageSquare}
        title="AI Assistant"
        description="Get personalized financial advice"
        onClick={() => console.log("AI assistant")}
      />
    </div>
  )
}
