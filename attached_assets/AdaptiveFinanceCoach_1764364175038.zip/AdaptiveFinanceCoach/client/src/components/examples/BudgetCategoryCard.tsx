import { BudgetCategoryCard } from '../budget-category-card'
import { Utensils, Car, ShoppingBag } from 'lucide-react'

export default function BudgetCategoryCardExample() {
  return (
    <div className="grid gap-4 md:grid-cols-3">
      <BudgetCategoryCard 
        category="Food & Dining" 
        allocated={10000} 
        spent={8500} 
        icon={<Utensils className="h-4 w-4 text-muted-foreground" />}
      />
      <BudgetCategoryCard 
        category="Transport" 
        allocated={5000} 
        spent={4800} 
        icon={<Car className="h-4 w-4 text-muted-foreground" />}
      />
      <BudgetCategoryCard 
        category="Shopping" 
        allocated={8000} 
        spent={9200} 
        icon={<ShoppingBag className="h-4 w-4 text-muted-foreground" />}
      />
    </div>
  )
}
