import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ShoppingBag, Coffee, Car, Home, Utensils, Zap } from "lucide-react";

interface Transaction {
  id: string;
  description: string;
  category: string;
  amount: number;
  date: string;
}

interface RecentTransactionsProps {
  transactions: Transaction[];
}

const categoryIcons: Record<string, any> = {
  Food: Utensils,
  Shopping: ShoppingBag,
  Transport: Car,
  Bills: Zap,
  Housing: Home,
  Coffee: Coffee,
};

export function RecentTransactions({ transactions }: RecentTransactionsProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Transactions</CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[400px] pr-4">
          <div className="space-y-4">
            {transactions.map((transaction) => {
              const Icon = categoryIcons[transaction.category] || ShoppingBag;
              return (
                <div
                  key={transaction.id}
                  className="flex items-center gap-4 p-3 rounded-md hover-elevate"
                  data-testid={`transaction-${transaction.id}`}
                >
                  <div className="p-2 rounded-md bg-muted">
                    <Icon className="h-4 w-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{transaction.description}</p>
                    <p className="text-xs text-muted-foreground">{transaction.date}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-mono font-semibold">₹{transaction.amount.toFixed(2)}</p>
                    <Badge variant="secondary" className="text-xs">{transaction.category}</Badge>
                  </div>
                </div>
              );
            })}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
