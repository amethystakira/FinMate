import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface FinancialHealthScoreProps {
  score: number;
  level: string;
}

export function FinancialHealthScore({ score, level }: FinancialHealthScoreProps) {
  const getScoreColor = (score: number) => {
    if (score >= 71) return "text-chart-2";
    if (score >= 41) return "text-chart-4";
    return "text-destructive";
  };

  const getScoreBackground = (score: number) => {
    if (score >= 71) return "from-chart-2/20 to-chart-2/5";
    if (score >= 41) return "from-chart-4/20 to-chart-4/5";
    return "from-destructive/20 to-destructive/5";
  };

  return (
    <Card className="overflow-hidden">
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
        <CardTitle className="text-lg font-semibold">Financial Health</CardTitle>
        <Badge variant="secondary" data-testid="text-financial-level">{level}</Badge>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-center py-6">
          <div className="relative">
            <svg className="w-32 h-32 transform -rotate-90">
              <circle
                cx="64"
                cy="64"
                r="56"
                stroke="currentColor"
                strokeWidth="8"
                fill="none"
                className="text-muted"
              />
              <circle
                cx="64"
                cy="64"
                r="56"
                stroke="currentColor"
                strokeWidth="8"
                fill="none"
                strokeDasharray={`${(score / 100) * 351.86} 351.86`}
                className={getScoreColor(score)}
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <div className={`text-3xl font-bold ${getScoreColor(score)}`} data-testid="text-financial-score">
                  {score}
                </div>
                <div className="text-xs text-muted-foreground">/ 100</div>
              </div>
            </div>
          </div>
        </div>
        <div className={`mt-4 p-4 rounded-md bg-gradient-to-br ${getScoreBackground(score)}`}>
          <p className="text-sm text-center">
            {score >= 71 && "Excellent! Your financial habits are strong."}
            {score >= 41 && score < 71 && "Good progress! Keep improving your savings."}
            {score < 41 && "Let's work on building better financial habits together."}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
