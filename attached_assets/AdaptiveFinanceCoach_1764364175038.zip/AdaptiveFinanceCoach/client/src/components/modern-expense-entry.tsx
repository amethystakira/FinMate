import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Mic, Check } from "lucide-react";
import { 
  Utensils, 
  Car, 
  ShoppingBag, 
  Zap, 
  Film, 
  Heart, 
  Plane,
  Coffee 
} from "lucide-react";

const categories = [
  { name: "Food", icon: Utensils, color: "bg-chart-1" },
  { name: "Transport", icon: Car, color: "bg-chart-2" },
  { name: "Shopping", icon: ShoppingBag, color: "bg-chart-3" },
  { name: "Bills", icon: Zap, color: "bg-chart-4" },
  { name: "Entertainment", icon: Film, color: "bg-chart-5" },
  { name: "Health", icon: Heart, color: "bg-chart-1" },
  { name: "Travel", icon: Plane, color: "bg-chart-2" },
  { name: "Coffee", icon: Coffee, color: "bg-chart-3" },
];

interface ModernExpenseEntryProps {
  onSave?: (expense: { amount: number; category: string; description: string }) => void;
}

export function ModernExpenseEntry({ onSave }: ModernExpenseEntryProps) {
  const [amount, setAmount] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [description, setDescription] = useState("");
  const [isListening, setIsListening] = useState(false);

  const handleSave = () => {
    if (amount && selectedCategory) {
      onSave?.({
        amount: parseFloat(amount),
        category: selectedCategory,
        description,
      });
      // Reset form
      setAmount("");
      setSelectedCategory("");
      setDescription("");
    }
  };

  const handleVoice = () => {
    setIsListening(!isListening);
    // TODO: Implement voice recognition
    console.log("Voice input toggled");
  };

  return (
    <Card>
      <CardContent className="p-6 space-y-6">
        <div className="space-y-2">
          <Label htmlFor="amount" className="text-base font-semibold">Amount</Label>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-2xl font-bold text-muted-foreground">
              ₹
            </span>
            <Input
              id="amount"
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              className="pl-12 text-3xl font-bold h-16 font-mono"
              data-testid="input-quick-amount"
            />
          </div>
        </div>

        <div className="space-y-3">
          <Label className="text-base font-semibold">Category</Label>
          <div className="grid grid-cols-4 gap-3">
            {categories.map((category) => {
              const Icon = category.icon;
              const isSelected = selectedCategory === category.name;
              return (
                <button
                  key={category.name}
                  onClick={() => setSelectedCategory(category.name)}
                  className={`relative flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all ${
                    isSelected
                      ? "border-primary bg-primary/5 scale-95"
                      : "border-transparent bg-muted hover-elevate"
                  }`}
                  data-testid={`category-${category.name.toLowerCase()}`}
                >
                  <div className={`p-2 rounded-lg ${category.color} bg-opacity-20`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <span className="text-xs font-medium">{category.name}</span>
                  {isSelected && (
                    <div className="absolute -top-1 -right-1 bg-primary rounded-full p-1">
                      <Check className="h-3 w-3 text-primary-foreground" />
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="description" className="text-base font-semibold">Description (Optional)</Label>
          <Input
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="What did you spend on?"
            data-testid="input-quick-description"
          />
        </div>

        <div className="flex gap-3">
          <Button
            onClick={handleSave}
            className="flex-1 h-12 text-base"
            disabled={!amount || !selectedCategory}
            data-testid="button-quick-save"
          >
            Add Expense
          </Button>
          <Button
            variant="outline"
            size="icon"
            className={`h-12 w-12 ${isListening ? "bg-destructive text-destructive-foreground" : ""}`}
            onClick={handleVoice}
            data-testid="button-quick-voice"
          >
            <Mic className="h-5 w-5" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
