import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Target, Calendar } from "lucide-react";

interface GoalCardProps {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  deadline?: string;
  onAddMoney?: (id: string) => void;
}

export function GoalCard({ 
  id, 
  name, 
  targetAmount, 
  currentAmount, 
  deadline,
  onAddMoney 
}: GoalCardProps) {
  const percentage = (currentAmount / targetAmount) * 100;

  return (
    <Card data-testid={`goal-card-${id}`}>
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-3">
        <CardTitle className="text-base font-semibold">{name}</CardTitle>
        <Target className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex items-center justify-center">
            <div className="relative">
              <svg className="w-28 h-28 transform -rotate-90">
                <circle
                  cx="56"
                  cy="56"
                  r="48"
                  stroke="currentColor"
                  strokeWidth="8"
                  fill="none"
                  className="text-muted"
                />
                <circle
                  cx="56"
                  cy="56"
                  r="48"
                  stroke="currentColor"
                  strokeWidth="8"
                  fill="none"
                  strokeDasharray={`${(percentage / 100) * 301.59} 301.59`}
                  className="text-chart-1"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-xl font-bold text-chart-1">
                    {Math.min(percentage, 100).toFixed(0)}%
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="text-center space-y-1">
            <p className="text-sm font-mono">
              <span className="font-semibold">₹{currentAmount.toFixed(0)}</span>
              <span className="text-muted-foreground"> / ₹{targetAmount.toFixed(0)}</span>
            </p>
            {deadline && (
              <div className="flex items-center justify-center gap-1 text-xs text-muted-foreground">
                <Calendar className="h-3 w-3" />
                <span>Due {deadline}</span>
              </div>
            )}
          </div>
        </div>
        <Button 
          className="w-full" 
          variant="outline"
          onClick={() => onAddMoney?.(id)}
          data-testid={`button-add-money-${id}`}
        >
          Add Money
        </Button>
      </CardContent>
    </Card>
  );
}
