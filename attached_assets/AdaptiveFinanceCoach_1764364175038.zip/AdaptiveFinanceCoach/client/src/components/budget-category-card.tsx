import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";

interface BudgetCategoryCardProps {
  category: string;
  allocated: number;
  spent: number;
  icon?: React.ReactNode;
}

export function BudgetCategoryCard({ category, allocated, spent, icon }: BudgetCategoryCardProps) {
  const percentage = (spent / allocated) * 100;
  const isOverBudget = percentage > 100;
  const isNearLimit = percentage > 80 && !isOverBudget;

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{category}</CardTitle>
        {icon}
        {isOverBudget && <Badge variant="destructive">Over Budget</Badge>}
        {isNearLimit && <Badge variant="default" className="bg-chart-4">Near Limit</Badge>}
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-baseline justify-between">
          <span className="text-2xl font-bold font-mono">₹{spent.toFixed(0)}</span>
          <span className="text-sm text-muted-foreground">of ₹{allocated.toFixed(0)}</span>
        </div>
        <Progress 
          value={Math.min(percentage, 100)} 
          className="h-2"
        />
        <p className="text-xs text-muted-foreground">
          {isOverBudget 
            ? `₹${(spent - allocated).toFixed(0)} over budget` 
            : `₹${(allocated - spent).toFixed(0)} remaining`}
        </p>
      </CardContent>
    </Card>
  );
}
