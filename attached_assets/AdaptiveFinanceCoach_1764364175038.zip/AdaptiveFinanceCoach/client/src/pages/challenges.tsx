import { useState } from "react";
import { ChallengeCard } from "@/components/challenge-card";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Trophy, Target, Zap } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function Challenges() {
  const [isCreatingChallenge, setIsCreatingChallenge] = useState(false);

  // TODO: Remove mock data
  const challenges = [
    { id: '1', category: 'Coffee', limit: 500, spent: 320, period: 'This Week', daysLeft: 3, active: true },
    { id: '2', category: 'Dining Out', limit: 2000, spent: 1850, period: 'This Month', daysLeft: 10, active: true },
    { id: '3', category: 'Shopping', limit: 3000, spent: 2100, period: 'This Month', daysLeft: 10, active: true },
    { id: '4', category: 'Entertainment', limit: 1500, spent: 1650, period: 'Last Month', daysLeft: 0, active: false },
  ];

  const activeChallenges = challenges.filter(c => c.active);
  const completedThisMonth = 2;
  const totalSaved = 1200;

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
      <div className="space-y-8 p-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Spending Challenges</h1>
            <p className="text-muted-foreground mt-2">Set limits and build better money habits</p>
          </div>
          <Dialog open={isCreatingChallenge} onOpenChange={setIsCreatingChallenge}>
            <DialogTrigger asChild>
              <Button size="lg" data-testid="button-create-challenge">
                <Plus className="h-4 w-4 mr-2" />
                New Challenge
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle className="text-2xl">Create Spending Challenge</DialogTitle>
                <DialogDescription>Set a spending limit for a specific category</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="challenge-category">Category</Label>
                  <Select>
                    <SelectTrigger id="challenge-category" data-testid="select-challenge-category">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="coffee">Coffee</SelectItem>
                      <SelectItem value="dining">Dining Out</SelectItem>
                      <SelectItem value="shopping">Shopping</SelectItem>
                      <SelectItem value="entertainment">Entertainment</SelectItem>
                      <SelectItem value="transport">Transport</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="limit">Spending Limit (₹)</Label>
                  <Input
                    id="limit"
                    type="number"
                    placeholder="500"
                    data-testid="input-challenge-limit"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="period">Time Period</Label>
                  <Select>
                    <SelectTrigger id="period" data-testid="select-challenge-period">
                      <SelectValue placeholder="Select period" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="week">This Week</SelectItem>
                      <SelectItem value="month">This Month</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button className="w-full" size="lg" data-testid="button-save-challenge">
                  Create Challenge
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          <Card className="border-0 bg-gradient-to-br from-chart-2/20 via-chart-2/10 to-transparent">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-4 rounded-xl bg-chart-2 text-white shadow-lg">
                  <Trophy className="h-8 w-8" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-muted-foreground mb-1">Completed</p>
                  <p className="text-3xl font-bold" data-testid="text-challenges-completed">{completedThisMonth}</p>
                  <p className="text-xs text-muted-foreground">This month</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 bg-gradient-to-br from-primary/20 via-primary/10 to-transparent">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-4 rounded-xl bg-primary text-primary-foreground shadow-lg">
                  <Target className="h-8 w-8" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-muted-foreground mb-1">Active</p>
                  <p className="text-3xl font-bold">{activeChallenges.length}</p>
                  <p className="text-xs text-muted-foreground">Ongoing challenges</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 bg-gradient-to-br from-chart-4/20 via-chart-4/10 to-transparent">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-4 rounded-xl bg-chart-4 text-white shadow-lg">
                  <Zap className="h-8 w-8" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-muted-foreground mb-1">Total Saved</p>
                  <p className="text-3xl font-bold font-mono">₹{totalSaved.toLocaleString()}</p>
                  <p className="text-xs text-muted-foreground">This month</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold">Active Challenges</h2>
            <p className="text-sm text-muted-foreground">{activeChallenges.length} in progress</p>
          </div>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {activeChallenges.map((challenge) => (
              <ChallengeCard key={challenge.id} {...challenge} />
            ))}
            
            {activeChallenges.length === 0 && (
              <Card className="col-span-full border-2 border-dashed">
                <CardContent className="p-12 text-center">
                  <div className="p-4 rounded-full bg-muted inline-flex mb-4">
                    <Target className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <h3 className="font-semibold text-lg mb-2">No Active Challenges</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Create your first challenge to start building better spending habits
                  </p>
                  <Button>Create Challenge</Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        <div>
          <h2 className="text-2xl font-bold mb-6">Completed Challenges</h2>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {challenges.filter(c => !c.active).map((challenge) => (
              <ChallengeCard key={challenge.id} {...challenge} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
