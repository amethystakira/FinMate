import { useState } from "react";
import { WelcomeBanner } from "@/components/welcome-banner";
import { EnhancedStatCard } from "@/components/enhanced-stat-card";
import { QuickActionCard } from "@/components/quick-action-card";
import { ExpenseChart } from "@/components/expense-chart";
import { SpendingTrendChart } from "@/components/spending-trend-chart";
import { RecentTransactions } from "@/components/recent-transactions";
import { ModernExpenseEntry } from "@/components/modern-expense-entry";
import { DollarSign, TrendingUp, Wallet, PiggyBank, Plus, Target, MessageSquare } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function Dashboard() {
  const [showExpenseEntry, setShowExpenseEntry] = useState(false);

  // TODO: Remove mock data - replace with real API calls
  const expenseData = [
    { category: 'Food', amount: 8500, color: 'hsl(var(--chart-1))' },
    { category: 'Transport', amount: 4200, color: 'hsl(var(--chart-2))' },
    { category: 'Shopping', amount: 6800, color: 'hsl(var(--chart-3))' },
    { category: 'Bills', amount: 5500, color: 'hsl(var(--chart-4))' },
    { category: 'Entertainment', amount: 3200, color: 'hsl(var(--chart-5))' },
  ];

  const trendData = [
    { month: 'Jan', income: 45000, expenses: 32000 },
    { month: 'Feb', income: 47000, expenses: 34500 },
    { month: 'Mar', income: 46000, expenses: 31000 },
    { month: 'Apr', income: 48000, expenses: 35500 },
    { month: 'May', income: 50000, expenses: 33000 },
    { month: 'Jun', income: 45000, expenses: 32500 },
  ];

  const transactions = [
    { id: '1', description: 'Grocery Shopping', category: 'Food', amount: 2500, date: '2 hours ago' },
    { id: '2', description: 'Uber Ride', category: 'Transport', amount: 350, date: '5 hours ago' },
    { id: '3', description: 'Coffee at Starbucks', category: 'Coffee', amount: 180, date: 'Yesterday' },
    { id: '4', description: 'Electricity Bill', category: 'Bills', amount: 1800, date: 'Yesterday' },
    { id: '5', description: 'Amazon Purchase', category: 'Shopping', amount: 4200, date: '2 days ago' },
    { id: '6', description: 'Restaurant Dinner', category: 'Food', amount: 1200, date: '3 days ago' },
    { id: '7', description: 'Petrol', category: 'Transport', amount: 2000, date: '3 days ago' },
    { id: '8', description: 'Movie Tickets', category: 'Entertainment', amount: 600, date: '4 days ago' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
      <div className="space-y-8 p-8">
        <WelcomeBanner
          userName="Rahul"
          financialHealth={78}
          insight="You've saved 15% more this month! Keep up the great work and you'll reach your emergency fund goal by December."
        />

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <EnhancedStatCard
            title="Total Balance"
            value="₹1,24,500"
            trend={12}
            icon={Wallet}
            testId="text-total-balance"
            subtitle="Across all accounts"
          />
          <EnhancedStatCard
            title="Monthly Income"
            value="₹45,000"
            trend={5}
            icon={DollarSign}
            testId="text-income"
            subtitle="This month"
          />
          <EnhancedStatCard
            title="Monthly Expenses"
            value="₹32,500"
            trend={-8}
            icon={TrendingUp}
            testId="text-expenses"
            subtitle="28% less than last month"
          />
          <EnhancedStatCard
            title="Total Savings"
            value="₹12,500"
            trend={15}
            icon={PiggyBank}
            testId="text-savings"
            subtitle="This month"
          />
        </div>

        <div>
          <h2 className="text-2xl font-bold mb-6">Quick Actions</h2>
          <div className="grid gap-4 md:grid-cols-3">
            <QuickActionCard
              icon={Plus}
              title="Add Expense"
              description="Log a new transaction quickly"
              onClick={() => setShowExpenseEntry(true)}
              testId="quick-action-add-expense"
            />
            <QuickActionCard
              icon={Target}
              title="Track Goals"
              description="Monitor your financial targets"
              onClick={() => console.log("Track goals")}
              testId="quick-action-track-goals"
            />
            <QuickActionCard
              icon={MessageSquare}
              title="AI Assistant"
              description="Get personalized financial advice"
              onClick={() => console.log("AI assistant")}
              testId="quick-action-ai-assistant"
            />
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <ExpenseChart data={expenseData} />
          <RecentTransactions transactions={transactions} />
        </div>

        <SpendingTrendChart data={trendData} />

        <Dialog open={showExpenseEntry} onOpenChange={setShowExpenseEntry}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-2xl">Add New Expense</DialogTitle>
              <DialogDescription>
                Quickly log your transaction with voice or manual entry
              </DialogDescription>
            </DialogHeader>
            <ModernExpenseEntry
              onSave={(expense) => {
                console.log("Expense saved:", expense);
                setShowExpenseEntry(false);
              }}
            />
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
