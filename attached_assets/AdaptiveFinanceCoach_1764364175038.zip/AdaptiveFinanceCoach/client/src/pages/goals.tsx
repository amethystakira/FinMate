import { useState } from "react";
import { GoalCard } from "@/components/goal-card";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Plus, Sparkles, TrendingUp } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function Goals() {
  const [isCreatingGoal, setIsCreatingGoal] = useState(false);

  // TODO: Remove mock data
  const goals = [
    { id: '1', name: 'Emergency Fund', targetAmount: 50000, currentAmount: 32000, deadline: 'Dec 2025' },
    { id: '2', name: 'New Laptop', targetAmount: 80000, currentAmount: 45000, deadline: 'Mar 2026' },
    { id: '3', name: 'Vacation Trip', targetAmount: 60000, currentAmount: 18000, deadline: 'Jun 2026' },
    { id: '4', name: 'Wedding Fund', targetAmount: 200000, currentAmount: 75000, deadline: 'Dec 2026' },
  ];

  const totalTarget = goals.reduce((sum, goal) => sum + goal.targetAmount, 0);
  const totalSaved = goals.reduce((sum, goal) => sum + goal.currentAmount, 0);
  const overallProgress = (totalSaved / totalTarget) * 100;

  const handleAddMoney = (goalId: string) => {
    console.log('Add money to goal:', goalId);
    // TODO: Implement add money functionality
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
      <div className="space-y-8 p-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Financial Goals</h1>
            <p className="text-muted-foreground mt-2">Track your progress towards your dreams</p>
          </div>
          <Dialog open={isCreatingGoal} onOpenChange={setIsCreatingGoal}>
            <DialogTrigger asChild>
              <Button size="lg" data-testid="button-create-goal">
                <Plus className="h-4 w-4 mr-2" />
                New Goal
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle className="text-2xl">Create Financial Goal</DialogTitle>
                <DialogDescription>Set a target and deadline for your savings goal</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="goal-name">Goal Name</Label>
                  <Input
                    id="goal-name"
                    placeholder="e.g., Emergency Fund, Dream Car"
                    data-testid="input-goal-name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="target-amount">Target Amount (₹)</Label>
                  <Input
                    id="target-amount"
                    type="number"
                    placeholder="50000"
                    data-testid="input-target-amount"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="deadline">Target Date</Label>
                  <Input
                    id="deadline"
                    type="date"
                    data-testid="input-deadline"
                  />
                </div>
                <Button className="w-full" size="lg" data-testid="button-save-goal">
                  Create Goal
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <Card className="border-0 bg-gradient-to-br from-chart-2/10 via-chart-2/5 to-transparent">
          <CardContent className="p-6">
            <div className="grid gap-6 md:grid-cols-2">
              <div className="space-y-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-2">Overall Progress</p>
                  <div className="flex items-baseline gap-2">
                    <p className="text-4xl font-bold font-mono">
                      {overallProgress.toFixed(0)}%
                    </p>
                    <p className="text-muted-foreground">of all goals</p>
                  </div>
                </div>
                <Progress value={overallProgress} className="h-3" />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Total Target</p>
                  <p className="text-2xl font-bold font-mono">₹{(totalTarget / 1000).toFixed(0)}k</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Total Saved</p>
                  <p className="text-2xl font-bold font-mono text-chart-2">₹{(totalSaved / 1000).toFixed(0)}k</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div>
          <h2 className="text-2xl font-bold mb-6">Your Goals</h2>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {goals.map((goal) => (
              <GoalCard
                key={goal.id}
                {...goal}
                onAddMoney={handleAddMoney}
              />
            ))}
            
            <Card className="flex items-center justify-center hover-elevate active-elevate-2 cursor-pointer border-2 border-dashed min-h-[320px]">
              <CardContent className="text-center p-6">
                <div className="p-4 rounded-full bg-primary/10 inline-flex mb-4">
                  <Plus className="h-8 w-8 text-primary" />
                </div>
                <h3 className="font-semibold text-lg mb-2">Add New Goal</h3>
                <p className="text-sm text-muted-foreground">Set a new financial target</p>
              </CardContent>
            </Card>
          </div>
        </div>

        <Card className="border-0 bg-gradient-to-br from-primary/10 via-primary/5 to-transparent">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="p-3 rounded-xl bg-primary text-primary-foreground shadow-lg">
                <Sparkles className="h-6 w-6" />
              </div>
              <div className="flex-1 space-y-3">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <TrendingUp className="h-4 w-4 text-chart-2" />
                    <h3 className="font-semibold text-lg">Smart Savings Tip</h3>
                  </div>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Save ₹500 more this week by skipping 2-3 coffee shop visits and making coffee at home. 
                    This will help you reach your Emergency Fund goal 5 days earlier! Small changes add up to big results.
                  </p>
                </div>
                <Button variant="outline" size="sm">
                  Create Savings Challenge
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
