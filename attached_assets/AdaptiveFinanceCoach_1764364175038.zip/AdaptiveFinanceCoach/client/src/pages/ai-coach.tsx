import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ChatMessage } from "@/components/chat-message";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send, Mic, TrendingUp, PiggyBank, FileText, Sparkles, Bot } from "lucide-react";

export default function AICoach() {
  const [message, setMessage] = useState("");
  const [isListening, setIsListening] = useState(false);
  
  // TODO: Remove mock data
  const [messages, setMessages] = useState<Array<{ role: "user" | "assistant"; content: string }>>([
    {
      role: "assistant",
      content: "Hello! I'm your AI Financial Coach. I can help you with budgeting, expense analysis, savings tips, and tax planning. How can I assist you today?",
    },
  ]);

  const quickActions = [
    { label: "Check Budget Status", icon: PiggyBank },
    { label: "Analyze Monthly Spending", icon: TrendingUp },
    { label: "Tax Estimation", icon: FileText },
    { label: "Savings Suggestions", icon: Sparkles },
  ];

  const creditScore = 750;
  const insights = [
    { title: "Spending Pattern", value: "Stable", change: "No unusual activity" },
    { title: "Savings Rate", value: "28%", change: "+5% from last month" },
    { title: "Bill Payments", value: "On Time", change: "Perfect record" },
  ];

  const handleSend = () => {
    if (!message.trim()) return;

    setMessages([...messages, { role: "user", content: message }]);
    
    // TODO: Replace with actual AI API call
    setTimeout(() => {
      setMessages(prev => [
        ...prev,
        {
          role: "assistant",
          content: "I've analyzed your request. Based on your current spending patterns, here are my recommendations...",
        },
      ]);
    }, 1000);

    setMessage("");
  };

  const handleVoiceInput = () => {
    setIsListening(!isListening);
    // TODO: Implement Web Speech API
    console.log('Voice input toggled');
  };

  const handleQuickAction = (action: string) => {
    setMessage(action);
    console.log('Quick action:', action);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
      <div className="h-[calc(100vh-4rem)] flex flex-col p-8 gap-8">
        <div>
          <h1 className="text-3xl font-bold">AI Financial Coach</h1>
          <p className="text-muted-foreground mt-2">Get personalized advice powered by artificial intelligence</p>
        </div>

        <div className="flex-1 grid gap-6 lg:grid-cols-3 min-h-0">
          <div className="lg:col-span-2 flex flex-col min-h-0">
            <Card className="flex-1 flex flex-col overflow-hidden border-0 bg-gradient-to-br from-card via-card to-muted/20">
              <CardHeader className="border-b bg-card/50 backdrop-blur-sm">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <Bot className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <CardTitle>Chat with Your AI Coach</CardTitle>
                    <p className="text-sm text-muted-foreground mt-1">Ask anything about your finances</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="flex-1 flex flex-col gap-4 p-6 overflow-hidden">
                <ScrollArea className="flex-1 pr-4">
                  <div className="space-y-4 pb-4">
                    {messages.map((msg, index) => (
                      <ChatMessage key={index} role={msg.role} content={msg.content} />
                    ))}
                  </div>
                </ScrollArea>
                
                <div className="space-y-3 flex-shrink-0">
                  <div className="flex gap-2 flex-wrap">
                    {quickActions.map((action) => (
                      <Badge
                        key={action.label}
                        variant="secondary"
                        className="cursor-pointer hover-elevate active-elevate-2 px-3 py-2 text-xs"
                        onClick={() => handleQuickAction(action.label)}
                        data-testid={`quick-action-${action.label.toLowerCase().replace(/\s+/g, '-')}`}
                      >
                        <action.icon className="h-3 w-3 mr-1" />
                        {action.label}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="flex gap-2">
                    <Textarea
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="Type your question here... (e.g., How can I save more money?)"
                      className="resize-none min-h-[60px]"
                      rows={2}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          handleSend();
                        }
                      }}
                      data-testid="input-chat-message"
                    />
                    <div className="flex flex-col gap-2">
                      <Button
                        size="icon"
                        className="h-[60px] w-12"
                        onClick={handleSend}
                        data-testid="button-send-message"
                      >
                        <Send className="h-4 w-4" />
                      </Button>
                      <Button
                        size="icon"
                        variant="outline"
                        className={`h-[60px] w-12 ${isListening ? "bg-destructive text-destructive-foreground" : ""}`}
                        onClick={handleVoiceInput}
                        data-testid="button-voice-chat"
                      >
                        <Mic className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="border-0 bg-gradient-to-br from-chart-2/20 via-chart-2/10 to-transparent">
              <CardHeader>
                <CardTitle className="text-lg">Credit Score</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center space-y-4">
                  <div>
                    <div className="text-5xl font-bold font-mono text-chart-2" data-testid="text-credit-score">
                      {creditScore}
                    </div>
                    <p className="text-sm font-medium text-muted-foreground mt-2">Good Credit Score</p>
                  </div>
                  <Progress value={75} className="h-2" />
                  <div className="space-y-3 text-left">
                    <div>
                      <p className="text-sm font-semibold mb-2">How to improve:</p>
                      <ul className="space-y-2 text-sm text-muted-foreground">
                        <li className="flex items-start gap-2">
                          <span className="text-chart-2 mt-0.5">•</span>
                          <span>Pay all bills on time consistently</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <span className="text-chart-2 mt-0.5">•</span>
                          <span>Keep credit utilization below 30%</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <span className="text-chart-2 mt-0.5">•</span>
                          <span>Avoid multiple credit applications</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 bg-gradient-to-br from-primary/10 via-primary/5 to-transparent">
              <CardHeader>
                <CardTitle className="text-lg">Quick Insights</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {insights.map((insight, index) => (
                  <div key={index} className="space-y-1">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium">{insight.title}</p>
                      <p className="text-sm font-bold">{insight.value}</p>
                    </div>
                    <p className="text-xs text-muted-foreground">{insight.change}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="border-0 bg-gradient-to-br from-chart-4/10 via-chart-4/5 to-transparent">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <Sparkles className="h-5 w-5 text-chart-4 mt-0.5" />
                  <div className="flex-1">
                    <h3 className="font-semibold text-sm mb-1">Monthly Insight</h3>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      You're spending 12% less than last month. Great job! Keep up this trend to reach 
                      your emergency fund goal faster.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
