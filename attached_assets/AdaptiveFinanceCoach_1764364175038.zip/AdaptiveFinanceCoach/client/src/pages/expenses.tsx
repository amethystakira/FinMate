import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ExpenseChart } from "@/components/expense-chart";
import { RecentTransactions } from "@/components/recent-transactions";
import { SpendingTrendChart } from "@/components/spending-trend-chart";
import { ModernExpenseEntry } from "@/components/modern-expense-entry";
import { Plus, Search, Filter, Download, TrendingDown, TrendingUp } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function Expenses() {
  const [isAddingExpense, setIsAddingExpense] = useState(false);

  // TODO: Remove mock data
  const expenseData = [
    { category: 'Food', amount: 8500, color: 'hsl(var(--chart-1))' },
    { category: 'Transport', amount: 4200, color: 'hsl(var(--chart-2))' },
    { category: 'Shopping', amount: 6800, color: 'hsl(var(--chart-3))' },
    { category: 'Bills', amount: 5500, color: 'hsl(var(--chart-4))' },
    { category: 'Entertainment', amount: 3200, color: 'hsl(var(--chart-5))' },
  ];

  const trendData = [
    { month: 'Jan', income: 45000, expenses: 32000 },
    { month: 'Feb', income: 47000, expenses: 34500 },
    { month: 'Mar', income: 46000, expenses: 31000 },
    { month: 'Apr', income: 48000, expenses: 35500 },
    { month: 'May', income: 50000, expenses: 33000 },
    { month: 'Jun', income: 45000, expenses: 32500 },
  ];

  const transactions = [
    { id: '1', description: 'Grocery Shopping', category: 'Food', amount: 2500, date: '2 hours ago' },
    { id: '2', description: 'Uber Ride', category: 'Transport', amount: 350, date: '5 hours ago' },
    { id: '3', description: 'Coffee at Starbucks', category: 'Coffee', amount: 180, date: 'Yesterday' },
    { id: '4', description: 'Electricity Bill', category: 'Bills', amount: 1800, date: 'Yesterday' },
    { id: '5', description: 'Amazon Purchase', category: 'Shopping', amount: 4200, date: '2 days ago' },
    { id: '6', description: 'Restaurant Dinner', category: 'Food', amount: 1200, date: '3 days ago' },
  ];

  const totalExpenses = 32500;
  const vsLastMonth = -8;

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
      <div className="space-y-8 p-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Expenses</h1>
            <p className="text-muted-foreground mt-2">Track and analyze your spending patterns</p>
          </div>
          <div className="flex gap-3">
            <Button variant="outline" size="lg" data-testid="button-export-expenses">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
            <Button size="lg" onClick={() => setIsAddingExpense(true)} data-testid="button-add-expense">
              <Plus className="h-4 w-4 mr-2" />
              Add Expense
            </Button>
          </div>
        </div>

        <Card className="border-0 bg-gradient-to-br from-primary/5 via-primary/10 to-primary/5">
          <CardContent className="p-6">
            <div className="grid gap-6 md:grid-cols-2">
              <div className="space-y-3">
                <p className="text-sm font-medium text-muted-foreground">Total Expenses This Month</p>
                <div className="flex items-baseline gap-3">
                  <p className="text-4xl font-bold font-mono">₹{totalExpenses.toLocaleString()}</p>
                  <div className={`flex items-center gap-1 px-3 py-1 rounded-full text-sm font-medium ${
                    vsLastMonth < 0 ? 'bg-chart-2/20 text-chart-2' : 'bg-destructive/20 text-destructive'
                  }`}>
                    {vsLastMonth < 0 ? (
                      <TrendingDown className="h-4 w-4" />
                    ) : (
                      <TrendingUp className="h-4 w-4" />
                    )}
                    <span>{Math.abs(vsLastMonth)}%</span>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground">
                  {vsLastMonth < 0 ? 'Less' : 'More'} than last month
                </p>
              </div>

              <div className="flex items-center gap-3 flex-wrap">
                <Badge variant="secondary" className="px-3 py-1">
                  127 transactions
                </Badge>
                <Badge variant="secondary" className="px-3 py-1">
                  Avg: ₹256/day
                </Badge>
                <Badge variant="secondary" className="px-3 py-1">
                  Top: Food (26%)
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="h-5 w-5" />
              Filter & Search
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search transactions..."
                  className="pl-10"
                  data-testid="input-search-expenses"
                />
              </div>
              <Select>
                <SelectTrigger className="w-full md:w-[200px]" data-testid="select-filter-category">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="food">Food</SelectItem>
                  <SelectItem value="transport">Transport</SelectItem>
                  <SelectItem value="shopping">Shopping</SelectItem>
                  <SelectItem value="bills">Bills</SelectItem>
                </SelectContent>
              </Select>
              <Select>
                <SelectTrigger className="w-full md:w-[200px]">
                  <SelectValue placeholder="This Month" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="this-month">This Month</SelectItem>
                  <SelectItem value="last-month">Last Month</SelectItem>
                  <SelectItem value="last-3-months">Last 3 Months</SelectItem>
                  <SelectItem value="this-year">This Year</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <div className="grid gap-6 lg:grid-cols-2">
          <ExpenseChart data={expenseData} />
          <RecentTransactions transactions={transactions} />
        </div>

        <SpendingTrendChart data={trendData} />

        <Dialog open={isAddingExpense} onOpenChange={setIsAddingExpense}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-2xl">Add New Expense</DialogTitle>
              <DialogDescription>
                Quickly log your transaction with voice or manual entry
              </DialogDescription>
            </DialogHeader>
            <ModernExpenseEntry
              onSave={(expense) => {
                console.log("Expense saved:", expense);
                setIsAddingExpense(false);
              }}
            />
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
