import { BudgetCategoryCard } from "@/components/budget-category-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Plus, Utensils, Car, ShoppingBag, Zap, Home, Film, Sparkles } from "lucide-react";

export default function Budget() {
  // TODO: Remove mock data
  const budgetCategories = [
    { category: 'Food & Dining', allocated: 10000, spent: 8500, icon: <Utensils className="h-4 w-4 text-muted-foreground" /> },
    { category: 'Transport', allocated: 5000, spent: 4800, icon: <Car className="h-4 w-4 text-muted-foreground" /> },
    { category: 'Shopping', allocated: 8000, spent: 9200, icon: <ShoppingBag className="h-4 w-4 text-muted-foreground" /> },
    { category: 'Bills & Utilities', allocated: 6000, spent: 5500, icon: <Zap className="h-4 w-4 text-muted-foreground" /> },
    { category: 'Housing', allocated: 15000, spent: 15000, icon: <Home className="h-4 w-4 text-muted-foreground" /> },
    { category: 'Entertainment', allocated: 4000, spent: 3200, icon: <Film className="h-4 w-4 text-muted-foreground" /> },
  ];

  const totalAllocated = budgetCategories.reduce((sum, cat) => sum + cat.allocated, 0);
  const totalSpent = budgetCategories.reduce((sum, cat) => sum + cat.spent, 0);
  const percentage = (totalSpent / totalAllocated) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
      <div className="space-y-8 p-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Budget Planner</h1>
            <p className="text-muted-foreground mt-2">Manage your monthly budget across categories</p>
          </div>
          <Button size="lg" data-testid="button-create-budget">
            <Plus className="h-4 w-4 mr-2" />
            New Category
          </Button>
        </div>

        <Card className="border-0 bg-gradient-to-br from-primary/5 via-primary/10 to-primary/5">
          <CardHeader>
            <CardTitle className="text-2xl">Monthly Overview</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid gap-6 md:grid-cols-3">
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-chart-1" />
                  <p className="text-sm font-medium text-muted-foreground">Total Budget</p>
                </div>
                <p className="text-3xl font-bold font-mono" data-testid="text-total-budget">
                  ₹{totalAllocated.toLocaleString()}
                </p>
              </div>
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-chart-4" />
                  <p className="text-sm font-medium text-muted-foreground">Total Spent</p>
                </div>
                <p className="text-3xl font-bold font-mono" data-testid="text-total-spent">
                  ₹{totalSpent.toLocaleString()}
                </p>
              </div>
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <div className={`h-2 w-2 rounded-full ${totalSpent > totalAllocated ? 'bg-destructive' : 'bg-chart-2'}`} />
                  <p className="text-sm font-medium text-muted-foreground">Remaining</p>
                </div>
                <p className={`text-3xl font-bold font-mono ${totalSpent > totalAllocated ? 'text-destructive' : 'text-chart-2'}`}>
                  ₹{Math.abs(totalAllocated - totalSpent).toLocaleString()}
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="font-medium">Overall Budget Usage</span>
                <span className="font-mono">{percentage.toFixed(1)}%</span>
              </div>
              <Progress value={Math.min(percentage, 100)} className="h-3" />
            </div>
          </CardContent>
        </Card>

        <div>
          <h2 className="text-2xl font-bold mb-6">Budget by Category</h2>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {budgetCategories.map((budget) => (
              <BudgetCategoryCard
                key={budget.category}
                category={budget.category}
                allocated={budget.allocated}
                spent={budget.spent}
                icon={budget.icon}
              />
            ))}
          </div>
        </div>

        <Card className="border-0 bg-gradient-to-br from-chart-1/10 via-chart-1/5 to-transparent">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="p-3 rounded-xl bg-chart-1 text-white shadow-lg">
                <Sparkles className="h-6 w-6" />
              </div>
              <div className="flex-1 space-y-3">
                <div>
                  <h3 className="font-semibold text-lg mb-1">AI Budget Recommendation</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    You're spending 15% more on Shopping this month. Consider reducing it by ₹1,500 
                    to stay on track with your savings goals. I can help you create a shopping plan!
                  </p>
                </div>
                <Button variant="outline" size="sm" data-testid="button-apply-suggestion">
                  View Detailed Analysis
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
