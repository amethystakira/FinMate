import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { LoanComparisonTable } from "@/components/loan-comparison-table";
import { Bell, Globe, Shield, CreditCard } from "lucide-react";

export default function Settings() {
  // TODO: Remove mock data
  const loans = [
    { id: '1', bank: 'HDFC Bank', interestRate: 8.5, emi: 15234, totalCost: 914040, tenure: 60, isBest: true },
    { id: '2', bank: 'State Bank of India', interestRate: 8.75, emi: 15456, totalCost: 927360, tenure: 60 },
    { id: '3', bank: 'ICICI Bank', interestRate: 9.0, emi: 15678, totalCost: 940680, tenure: 60 },
    { id: '4', bank: 'Axis Bank', interestRate: 9.25, emi: 15901, totalCost: 954060, tenure: 60 },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
      <div className="space-y-8 p-8">
        <div>
          <h1 className="text-3xl font-bold">Settings</h1>
          <p className="text-muted-foreground mt-2">Manage your account preferences and settings</p>
        </div>

        <div className="grid gap-6">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Shield className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <CardTitle>Profile Settings</CardTitle>
                  <CardDescription>Update your personal information</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="first-name">First Name</Label>
                  <Input id="first-name" placeholder="John" data-testid="input-first-name" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="last-name">Last Name</Label>
                  <Input id="last-name" placeholder="Doe" data-testid="input-last-name" />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input id="email" type="email" placeholder="john@example.com" data-testid="input-email" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input id="phone" type="tel" placeholder="+91 98765 43210" data-testid="input-phone" />
              </div>
              <Separator />
              <Button data-testid="button-save-profile">Save Changes</Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="p-2 bg-chart-2/10 rounded-lg">
                  <Globe className="h-5 w-5 text-chart-2" />
                </div>
                <div>
                  <CardTitle>Preferences</CardTitle>
                  <CardDescription>Customize your experience</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="currency">Currency</Label>
                  <Select defaultValue="inr">
                    <SelectTrigger id="currency" data-testid="select-currency">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="inr">INR (₹)</SelectItem>
                      <SelectItem value="usd">USD ($)</SelectItem>
                      <SelectItem value="eur">EUR (€)</SelectItem>
                      <SelectItem value="gbp">GBP (£)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="language">Language</Label>
                  <Select defaultValue="en">
                    <SelectTrigger id="language" data-testid="select-language">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="hi">हिंदी (Hindi)</SelectItem>
                      <SelectItem value="mr">मराठी (Marathi)</SelectItem>
                      <SelectItem value="ta">தமிழ் (Tamil)</SelectItem>
                      <SelectItem value="te">తెలుగు (Telugu)</SelectItem>
                      <SelectItem value="bn">বাংলা (Bengali)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="p-2 bg-chart-4/10 rounded-lg">
                  <Bell className="h-5 w-5 text-chart-4" />
                </div>
                <div>
                  <CardTitle>Notifications</CardTitle>
                  <CardDescription>Control how you receive updates</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between py-3">
                <div className="space-y-0.5">
                  <Label htmlFor="budget-alerts" className="text-base">Budget Alerts</Label>
                  <p className="text-sm text-muted-foreground">Get notified when you approach budget limits</p>
                </div>
                <Switch id="budget-alerts" defaultChecked data-testid="switch-budget-alerts" />
              </div>
              <Separator />
              <div className="flex items-center justify-between py-3">
                <div className="space-y-0.5">
                  <Label htmlFor="goal-updates" className="text-base">Goal Updates</Label>
                  <p className="text-sm text-muted-foreground">Track progress towards your financial goals</p>
                </div>
                <Switch id="goal-updates" defaultChecked data-testid="switch-goal-updates" />
              </div>
              <Separator />
              <div className="flex items-center justify-between py-3">
                <div className="space-y-0.5">
                  <Label htmlFor="weekly-reports" className="text-base">Weekly Reports</Label>
                  <p className="text-sm text-muted-foreground">Receive weekly financial summaries via email</p>
                </div>
                <Switch id="weekly-reports" defaultChecked data-testid="switch-weekly-reports" />
              </div>
              <Separator />
              <div className="flex items-center justify-between py-3">
                <div className="space-y-0.5">
                  <Label htmlFor="ai-insights" className="text-base">AI Insights</Label>
                  <p className="text-sm text-muted-foreground">Get personalized financial tips and recommendations</p>
                </div>
                <Switch id="ai-insights" defaultChecked data-testid="switch-ai-insights" />
              </div>
            </CardContent>
          </Card>

          <div>
            <div className="mb-6">
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2 bg-chart-1/10 rounded-lg">
                  <CreditCard className="h-5 w-5 text-chart-1" />
                </div>
                <h2 className="text-2xl font-bold">Loan Comparison</h2>
              </div>
              <p className="text-muted-foreground">Compare loan offers from different banks</p>
            </div>
            <LoanComparisonTable loans={loans} />
          </div>
        </div>
      </div>
    </div>
  );
}
